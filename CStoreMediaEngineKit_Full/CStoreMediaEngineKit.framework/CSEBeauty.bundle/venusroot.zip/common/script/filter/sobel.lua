local apolloengine = require "apolloengine"
local mathfunction = require "mathfunction"

local sobel = {}
sobel.sl = 0;

sobel.Queue = 117;

function sobel:_SetParam(size)  -- fortest
  self.height= size:y();
  self.hOffset=1.0/self.height;
  self.width=size:x();
  self.wOffset=1.0/self.width;
  self.sl:SetParameter(self.PIXEL_OFFSETS, mathfunction.vector2( self.wOffset, self.hOffset ) );
  self.sl:SetParameter(self.EDGE_STRENGTH, mathfunction.vector1(0.3) );
end

function sobel:Initialize(host, size)
    --<!--  set the offsets parameters in vertex shader -->
  self.PIXEL_OFFSETS = apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,"PIXEL_OFFSETS");   
  self.EDGE_STRENGTH = apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,"EDGE_STRENGTH");
  self.SQUARE_COORDINATE = apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.INTERNAL,"SQUARE_COORDINATE"); 
  self.sl = host:CreateRenderObject("comm:documents/filter/material/sobel.material" );
  self:_SetParam(size);
  return self.Queue;
end

function sobel:Resizeview(size)
  self:_SetParam(size);
end

function sobel:Process(pipeline, Original, Scene, Output)
  Output:PushRenderTarget();
  Output:ClearBuffer( apolloengine.RenderTargetEntity.CF_COLOR );
  self.sl:SetParameter(
		apolloengine.ShaderEntity.TEXTURE_DIFFUSE,
		Scene:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0 ) );
	self.sl:Draw(pipeline);
end

return sobel;