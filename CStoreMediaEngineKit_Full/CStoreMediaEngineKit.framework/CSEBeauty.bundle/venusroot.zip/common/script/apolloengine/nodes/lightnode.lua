local GenricNode = require "apolloengine.nodes.genericnode"
local apollocore = require "apollocore"
local apolloengine = require "apollocore"
local venuscore = require "venuscore"
local mathfunction = require "mathfunction"
local defined = require "window.editor.system.defined"
local QuadNode  = require "apolloengine.nodes.quadnode"
local LightNode =  GenricNode:extend("LightNode");
local LineNode = require "apolloengine.nodes.linenode"
local venuscore = require "venuscore"


venuscore.BundleSystem:OnDeserialize(LightNode:GetTypeName(),
        function(cls,attributes,nodes)
          table.insert(nodes,cls);
        end)

function LightNode:new()
  LightNode.super.new(self);
  --local lt = lightType or apollocore.LT_AMBIENT;
 -- local lt = defined.LightTypes["AmbientLight"];
 -- local lightComponent = self:CreateComponent(apolloengine.Node.CT_LIGHT);
 -- --lightComponent:SetLightType(lt);
 -- lightComponent.LightType = lt;
--
 -- --self:AttachComponent(lightComponent);
 -- self.lighttype = lightComponent.LightType;
 -- -----------------------编辑器模式下光照贴图------------------------
 -- if _KRATOSEDITOR then
 --   local lighttexpath = "comm:documents/texture/light/"..tostring("AmbientLight")..".png"; 
 --   self.quadnode = QuadNode();
 --   self.quadnode:Create2DTexRenderComponent("comm:documents/material/quadtexture.material",lighttexpath);
 --   self:AttachNode(self.quadnode);
 --   self.quadnode:SetParentNode(self); --将lightnode存储在quadnode里面作为父节点方便拾取的时候做特殊处理
--
 --   self.linenode = LineNode();
 --   self.linenode:CreateLightGizmo(self);
 --   self:AttachNode(self.linenode);
 -- end
end

function LightNode:GetLightType()
  return self.lighttype;
end

function LightNode:SetColor(c)
  local lightComponent = self:GetComponent(apollocore.Node.CT_LIGHT);
  lightComponent:SetColor(c);
end

function LightNode:SetDirection(dir)
  local lightComponent = self:GetComponent(apollocore.Node.CT_LIGHT);
  lightComponent:SetDirection(dir);
end

function LightNode:GetLineNode() --得到LineNode 用于反射更新
  --  lightnode(不可拾取)
  --   /       \
  -- quadnode  linenode
  -- (可拾取)   (不允许拾取)
  return self.linenode;
end

function LightNode:SetTexture(texpath)
  self.quadnode:SetTexture(texpath);
end

function LightNode:SetShowLineNode(show) --控制光照辅助体显示 关联拾取逻辑
  if self.linenode then
    self.linenode:SetShow(show);
  end
end

return LightNode;

