local GenericNode = require "apolloengine.nodes.genericnode"
local apolloengine = require "apollocore"
local mathfunction = require "mathfunction"
local venuscore = require "venuscore"
local RttiManager = require "venuscore.rtti.rttimanager"
local QuadNode = require "apolloengine.nodes.quadnode"
local LineNode = require "apolloengine.nodes.linenode"
local CameraNode =  GenericNode:extend("CameraNode");



venuscore.BundleSystem:OnDeserialize(CameraNode:GetTypeName(),
  function(cls,atrributes,nodes)
    --使用父类genericnode的反序列化，处理挂接关系
    local parent = cls.super;
    local parentfunc = venuscore.BundleSystem.DeserializeDelegates[parent:GetTypeName()];
    parentfunc(cls,atrributes,nodes);
    local camera;
    if cls then
      for k,v in pairs(atrributes) do
        if v[1] == "componentList" then
          local componentList = v[2];
          for key,value in pairs(componentList) do
            if string.find(key,'Userscript_') == nil and value:GetTypeName() == "CameraComponent" then
              camera = value;
            end
          end
        end
      end
      for k,v in pairs(atrributes) do 
        if v[1] == "PosteffctList" then
          local posteffectlist = v[2];
          for key,value in pairs(posteffectlist) do
            local post = value["PostEffectEntity"];
            if value["Status"] == true then
              camera:AttachPostEffect(post);
            end
          end
        end
      end
    end
  end)



CameraNode:MemberRegister("PosteffctList");

function CameraNode:new()
  CameraNode.super.new(self)
  self.PosteffctList = {};  --保存所有的Posteffct参数
  self:_CreateCamera(mathfunction.vector2(128,128),
    0.1, 10,
    mathfunction.vector3(0,0,1),
		mathfunction.vector3(0,0,0),
		mathfunction.vector3(0,1,0));

   -----------------------编辑器模式下相机贴图------------------------
  if _KRATOSEDITOR then
    self.quadnode = QuadNode();
    self.quadnode:Create2DTexRenderComponent("comm:documents/material/quadtexture.material","comm:documents/texture/camera/camera.png");
    self:AttachNode(self.quadnode);
    self.quadnode:SetParentNode(self); --将cameranode存储在quadnode里面作为父节点方便拾取的时候做特殊处理

    self.linenode = LineNode();
    self.linenode:CreateCameraGizmo(self);
    self:AttachNode(self.linenode);

  end

  --self:SetName("CameraNode");
end


function CameraNode:_CreateCamera(size,near,far,pos,lookat,up)
  self.camera = self:CreateComponent(apolloengine.Node.CT_CAMERA);
  self.camera:CreatePerspectiveProjection(near, far);
  self.camera:LookAt(pos, lookat, up);
  self.camera:Recalculate();--手动更新矩阵
  self.camera:Activate();--激活主摄像机
end


function CameraNode:AddPosteffect(poststr)
  local path = poststr..".lua";
  local post = self.camera:CreatePostEffect();
  post:PushMetadata(apolloengine.PathMetadata(path));
  post:CreateResource();
  local isAttached = true;
  local posteffectEntity = post;
  posteffectEntity.ScriptPath = path;
  local key = #self.PosteffctList + 1;
  self.PosteffctList[key] = {["PostEffectEntity"] = posteffectEntity,["PostEffectPath"] = poststr,["Status"] = isAttached};
  --table.insert(self.PosteffctList,{["PostEffectEntity"] = posteffectEntity,["PostEffectPath"] = poststr,["Status"] = isAttached});
end

function CameraNode:DeletePosteffect(value)
  self.camera:DeletePostEffect(value.PostEffectEntity)
  for k,v in pairs(self.PosteffctList) do
    if v == value then
      table.remove(self.PosteffctList, k)
      break;
    end
  end
end


function CameraNode:AttachPosteffect(post)
  self.camera:AttachPostEffect(post["PostEffectEntity"]);
  post["Status"] = true;
end

function CameraNode:DetachPosteffect(post)
   self.camera:DetachPostEffect(post["PostEffectEntity"]);
   post["Status"] = false;
end

function CameraNode:GetNativeNode()
  return self.node
end


function CameraNode:GetLineNode() --得到视锥体Node 用于反射更新
  --  cameranode(不可拾取)
  --   /       \
  -- quadnode  linenode
  -- (可拾取)   (不允许拾取)
  return self.linenode;
end

function CameraNode:SetShowLineNode(show) --控制视锥体显示 关联拾取逻辑
  if self.linenode then
    self.linenode:SetShow(show);
  end
end

return CameraNode;