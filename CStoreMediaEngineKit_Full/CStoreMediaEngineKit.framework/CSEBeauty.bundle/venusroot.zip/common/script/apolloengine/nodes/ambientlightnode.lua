local apolloengine = require "apollocore"
local defined = require "window.editor.system.defined"
local LightNode = require "apolloengine.nodes.lightnode"
local QuadNode  = require "apolloengine.nodes.quadnode"
local LineNode = require "apolloengine.nodes.linenode"
local AmbientLightNode =  LightNode:extend("AmbientLightNode");
local venuscore = require "venuscore"

venuscore.BundleSystem:OnDeserialize(AmbientLightNode:GetTypeName(),
        function(cls,attributes,nodes)
          table.insert(nodes,cls);
        end)

function AmbientLightNode:new()
  AmbientLightNode.super.new(self);
  
   local lt = defined.LightTypes["AmbientLight"];
  local lightComponent = self:CreateComponent(apolloengine.Node.CT_LIGHT);
  lightComponent.LightType = lt;
  --self:AttachComponent(lightComponent);
  self.lighttype = lightComponent.LightType;
  
  if _KRATOSEDITOR then
    local lighttexpath = "comm:documents/texture/light/".."AmbientLight"..".png"; 
    self.quadnode = QuadNode();
    self.quadnode:Create2DTexRenderComponent("comm:documents/material/quadtexture.material",lighttexpath);
    self:AttachNode(self.quadnode);
    self.quadnode:SetParentNode(self); --将lightnode存储在quadnode里面作为父节点方便拾取的时候做特殊处理

    self.linenode = LineNode();
    self.linenode:CreateLightGizmo(self);
    self:AttachNode(self.linenode);
  end
end

return AmbientLightNode;

