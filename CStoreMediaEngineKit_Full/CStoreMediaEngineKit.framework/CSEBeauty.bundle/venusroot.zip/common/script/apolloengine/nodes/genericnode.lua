local mathfunction = require "mathfunction"
local apollocore = require "apollocore"
local venuscore = require "venuscore"

local GenericNode =  venuscore.ActorNode:extend("GenericNode");

venuscore.BundleSystem:OnSerialize("Layer",
        function(obj)
          return "string",tostring(tonumber(obj));
        end
)

venuscore.BundleSystem:OnSerialize("LayerMask",
        function(obj)
          return "string",tostring(tonumber(obj));
        end
)

venuscore.BundleSystem:OnDeserialize(GenericNode:GetTypeName(),
        function(cls,attributes,nodes)
          for k,v in pairs(attributes) do
            if v[1] == "componentList" then
              local componentList = v[2];
              for key,value in pairs(componentList) do
                if string.find(key,'Userscript_') == nil and value:GetTypeName() ~= "TransformComponent" then
                  cls:GetNativeNode():AttachComponent(value);
                end
              end
            elseif v[1] == "childnode" then
              cls:AttachNode(v[2]);
            end
          end
          table.insert(nodes,cls);
        end)

--Node的layer需要调用转换为number
venuscore.BundleSystem:OnDeserialize(apollocore.Node:GetTypeName(),
        function(cls,attributes)
          for _, attr in pairs(attributes) do
            if attr then
              if attr[1] == "Layer" then
                local layer = venuscore.Utility:ConvertStringToUInt64(attr[2]);
                cls[attr[1]] = layer;
              else
                cls[attr[1]] = attr[2];
              end
            end
          end
        end
)

--CameraComponent的layer需要调用转换为number
venuscore.BundleSystem:OnDeserialize(apollocore.CameraComponent:GetTypeName(),
        function(cls,attributes)
          for _, attr in pairs(attributes) do
            if attr then
              if attr[1] == "LayerMask" then
                local layer = venuscore.Utility:ConvertStringToUInt64(attr[2]);
                cls[attr[1]] = layer;
              else
                cls[attr[1]] = attr[2];
              end
            end
          end
        end
)
      
--RenderComponent需要调用CeateResource
venuscore.BundleSystem:OnDeserialize(apollocore.RenderComponent:GetTypeName(),
  function(cls,attributes)
    for _, attr in pairs(attributes) do
      if attr then
        if attr[1] == "BindBox" then
          cls["OriginalBindBox"] = attr[2];
        else
          cls[attr[1]] = attr[2];
        end
      end
    end
    cls:CreateResource();
  end
)

--PosteffectEntity需要调用CeateResource
venuscore.BundleSystem:OnDeserialize(apollocore.PostEffectEntity:GetTypeName(),
  function(cls,attributes)
    local parameterlist = nil;
    local queue = nil;
    for _, attr in pairs(attributes) do
      if attr[1] == "ScriptPath" then
        local MeshData = attr[2];
        local path = MeshData[1].Path;
        cls:PushMetadata(apollocore.PathMetadata(path));
        cls:CreateResource();
      elseif attr[1] == "Queue" then
        queue = attr[2];
      else
        parameterlist = attr[2];
      end
    end
    cls.Parameters = parameterlist; 
    cls.Queue = queue;
  end
)

--RenderTargetEntity需要调用CeateResource
venuscore.BundleSystem:OnDeserialize(apollocore.RenderTargetEntity:GetTypeName(),
  function(cls,attributes)
    for _, attr in pairs(attributes) do
      if attr then
        cls[attr[1]] = attr[2];
      end
    end
    cls:CreateResource();
  end
)

--ScriptComponent反序列化特殊处理
venuscore.BundleSystem:OnDeserialize(apollocore.ScriptComponent:GetTypeName(),
  function(cls,attributes)
    for _, attr in pairs(attributes) do
      if attr then
        if attr[1] == "Instances" then
          local instances = attr[2];
          for path,data in pairs(instances) do
            cls:InsertInstance(data, path);
          end
        end
      end
    end
  end
)

--ScriptComponent下脚本数据反序列化特殊处理
venuscore.BundleSystem:OnDeserializeInit(apollocore.ScriptComponent:GetTypeName(),
  function(typename)
    local instance = {};
    return instance;
  end
)

venuscore.BundleSystem:OnDeserialize(apollocore.AnimationComponent:GetTypeName(),
  function(cls,attributes)
    for _, attr in pairs(attributes) do
      if attr then
          cls[attr[1]] = attr[2];
      end
    end
    cls:CreateResource();
  end
)

venuscore.BundleSystem:OnSerializeStarted(apollocore.AnimationComponent:GetTypeName(),
  function(component,data)
    component:OnSerializeStarted();
  end
)

venuscore.BundleSystem:OnSerializeFinished(apollocore.AnimationComponent:GetTypeName(),
  function(component,data)
    component:OnSerializeFinished();
  end
)

venuscore.BundleSystem:OnDeserializeFinished(apollocore.AnimationComponent:GetTypeName(),
  function(component,data)
    component:OnDeserializeFinished();
  end
)

venuscore.BundleSystem:OnDeserialize(apollocore.SkeletonComponent:GetTypeName(),
  function(cls,attributes)
    for _, attr in pairs(attributes) do
      if attr then
          cls[attr[1]] = attr[2];
      end
    end
    cls:CreateResource();
  end
)



GenericNode:MemberRegister("node");
GenericNode:MemberRegister("_version");


--isDeserialize: 标识是否是通过反序列化创建对象
function GenericNode:new() 
  --GenericNode.super.new(self);
  self.node = apollocore.Node();  --从C++开始序列化，这里的node就不需要序列化了
  self.node._Script = self;
  self._trans = self:CreateComponent(apollocore.Node.CT_TRANSFORM); --默认会有一个transform component
  self._trans:SetLocalPosition(mathfunction.vector3(0.0,0.0,0.0));
  self.ScriptComponents = {}; --用来保存脚本component对象
  self._version = 1;
end

function GenericNode:SetLocalRotation(q)
  self._trans:SetLocalRotation(q);
end

function GenericNode:CreateComponent(ct)
  local component = nil;
  if self.node then
    component = self.node:CreateComponent(ct);
  end
  return component;
end

function GenericNode:GetComponent(ct)
  local component = nil;
  if self.node then
    component = self.node:GetComponent(ct);
  end
  return component;
end


function GenericNode:Update(def)
  local components = self.node.Components;
  for comType, com in pairs(components) do
    local tm = getmetatable(com);
    if tm.Update then
      com:Update(def);
    end
  end
end


function GenericNode:SetLayer(layer)
  self.node:SetLayer(layer);
end

function GenericNode:AddUserscript(scriptpath)
  local func,errorstr = loadfile(venuscore.IFileSystem:PathAssembly(scriptpath));
  if not errorstr then
    local temp= func(); 
    local scriptEntity = temp(scriptpath);
    local pathDir, pathName = string.match(scriptpath, "(.+)[:/]([^/]*)%.%w+$");
    self.ScriptComponents["Userscript_"..pathName] = scriptEntity;
  end
end

function GenericNode:DeleteUserscript(value)
  for k, v in pairs(self.componentList) do
    if v == value then
      self.ScriptComponents[k] = nil;
    end
  end
end

function GenericNode:OnSerializeStarted()
  --循环所有的component,调用其回调
  
  local components = self.node.Components;
  for comType, comp in pairs(components) do
    local typename = comp:GetTypeName();
    if venuscore.BundleSystem.SerializeStartedDelegates[typename] then  
      local func = venuscore.BundleSystem.SerializeStartedDelegates[typename];
      func(comp,nil);
    end
  end
end

function GenericNode:OnSerializeFinished()
  --循环所有的component,调用其回调
  local components = self.node.Components;
  for comType, comp in pairs(components) do
    local typename = comp:GetTypeName();
      if venuscore.BundleSystem.SerializeFinishedDelegates[typename] then  
        local func = venuscore.BundleSystem.SerializeFinishedDelegates[typename];
        func(comp,nil);
    end
  end
end


function GenericNode:OnDeserializeFinished()
  --循环所有的component,调用其回调
  local components = self.node.Components;
  for comType, comp in pairs(components) do
    local typename = comp:GetTypeName();
    if venuscore.BundleSystem.DeserializeFinishedDelegates[typename] then  
      local func = venuscore.BundleSystem.DeserializeFinishedDelegates[typename];
      func(comp,nil);
    end
  end
end

function GenericNode:GetNativeNode()
  return self.node;
end

function GenericNode:InitializeNodeWithDefaultMaterial(mesh, isMeshKeepSource, bindbox, material)
  local mu = apollocore.VertexBufferEntity.MU_STATIC;
  if isMeshKeepSource then
    mu = apollocore.VertexBufferEntity.MU_DYNAMIC;
  end
  local RenderComponent = self:CreateComponent(apollocore.Node.CT_RENDER);
  RenderComponent:PushMetadata(apollocore.RenderObjectMeshFileMetadate(mu, mesh));

  RenderComponent:PushMetadata(
          apollocore.RenderObjectMaterialMetadata(
                  apollocore.PathMetadata(material)));
  RenderComponent:CreateResource();
  RenderComponent:SetBindBox(bindbox);
  self.TEXTURE_DIFFUSE = apollocore.IMaterialSystem:NewParameterSlot(apollocore.ShaderEntity.UNIFORM,"TEXTURE_DIFFUSE");
  self.TEXTURE_SHADOW_DEPTH = apollocore.IMaterialSystem:NewParameterSlot(apollocore.ShaderEntity.UNIFORM,"TEXTURE_SHADOW_DEPTH");
  self.blankimage = apollocore.TextureEntity();
  self.blankimage:PushMetadata(apollocore.TextureFileMetadata(
          apollocore.TextureEntity.TU_STATIC,
          apollocore.TextureEntity.PF_AUTO,1,true,
          apollocore.TextureEntity.TW_CLAMP_TO_EDGE,
          apollocore.TextureEntity.TW_CLAMP_TO_EDGE,
          apollocore.TextureEntity.TF_LINEAR,
          apollocore.TextureEntity.TF_LINEAR_MIPMAP_LINEAR,
          "comm:documents/texture/material/blank.jpg"));
  self.blankimage:CreateResource();
  RenderComponent:SetParameter(self.TEXTURE_DIFFUSE,self.blankimage);
  RenderComponent:SetParameter(self.TEXTURE_SHADOW_DEPTH,self.blankimage);
end

return GenericNode;