local GenericNode = require "apolloengine.nodes.genericnode"
local apolloengine = require "apollocore"
local apollocore = require "apollocore"
local mathfunction = require "mathfunction"


local LineNode = GenericNode:extend("LineNode");


function LineNode:new()
  LineNode.super.new(self);
  self.isShow = true;
  self:SetLayer(apolloengine.LayerMask.MC_MASK_EDITOR_SCENE_LAYER);
end

--------------------------------------------------摄像机视锥体相关内容--------------------------------------------------
function LineNode:CreateCameraGizmo(cameranode)
   
  self.renderComponent = self:CreateComponent(apolloengine.Node.CT_RENDER);
  self.renderComponent:EraseRenderProperty(apolloengine.RenderObjectEntity.RP_CULL);
  self.renderComponent:SetBindBox(mathfunction.Aabbox3d(mathfunction.vector3(0,0,0),mathfunction.vector3(0,0,0)));--无法被拾取

  
  local frustumpointset = {};
  local cameranodecomponent = cameranode:GetComponent(apolloengine.Node.CT_CAMERA);
  self.FrustumVertexStream = apolloengine.VertexStream();
  self.FrustumVertexStream:SetVertexType(apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    apolloengine.VertexBufferEntity.DT_FLOAT,
    apolloengine.VertexBufferEntity.DT_HALF_FLOAT,
    3);
  self.FrustumVertexStream:ReserveBuffer(8);--预先分配顶点的内存  8
  local camerafrustum = cameranodecomponent:GetFrustum();
  for i = 0,7 do
  	table.insert(frustumpointset,camerafrustum:GetCorner(i));
  end
  --local newpoint =  mathfunction.vector4(0, 0, 0, 1);
  for i = 1, #frustumpointset do
    --local point = frustumpointset[i];
    --newpoint:Set(point:x(),point:y(),point:z(),1);
    self.FrustumVertexStream:PushVertexData(
      apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
      frustumpointset[i]);
  end


  self.FrustumIndexStream = apolloengine.IndicesStream();
  self.FrustumIndexStream:SetIndicesType(
    apolloengine.IndicesBufferEntity.IT_UINT16);
  self.FrustumIndexStream:ReserveBuffer(24);--12条线
  
  local IndexTable = {2,6,3,7,0,4,1,5,0,1,1,3,3,2,2,0,4,5,5,7,7,6,6,4};
  for i = 1,#IndexTable do
    self.FrustumIndexStream:PushIndicesData(IndexTable[i]);
  end

 
  
  self.renderComponent:PushMetadata(
    apolloengine.RenderObjectMaterialMetadata(
      apolloengine.PathMetadata("comm:documents/material/gizmo.material")));
  local gridColor = apollocore.IMaterialSystem:NewParameterSlot(apollocore.ShaderEntity.UNIFORM,"POINT_COLOR");
  self.renderComponent:PushMetadata(
    apolloengine.RenderObjectMeshMetadate( 
      apolloengine.RenderObjectEntity.RM_LINES,
      apolloengine.ReferenceVertexMetadata(        
        apolloengine.VertexBufferEntity.MU_DYNAMIC,--使用可以修改的显存区域
        self.FrustumVertexStream),
      apolloengine.ReferenceIndicesMetadata(
        apolloengine.VertexBufferEntity.MU_STATIC,--使用不可修改的显存区域
        self.FrustumIndexStream)));

  self.renderComponent:CreateResource();
  self.renderComponent:SetParameter(gridColor,mathfunction.vector4(0.5,0.5,0.5,1.0));
  --self:AttachComponent(self.renderComponent);
end



function LineNode:UpdateCameraGizmo(cameranode) --更新摄像机视锥体
  local cameranodecomponent = cameranode:GetComponent(apolloengine.Node.CT_CAMERA);
  if cameranodecomponent == nil then
    return;
  end
  
  local frustumpointset = {};
  

  local camerafrustum = cameranodecomponent:GetFrustum();
  for i = 0,7 do
    local point = camerafrustum:GetCorner(i);
    table.insert(frustumpointset,point);
  end
  local index_vertex = self.FrustumVertexStream:GetAttributeIndex(apolloengine.ShaderEntity.ATTRIBUTE_POSITION);
  --local newpoint =  mathfunction.vector4(0, 0, 0, 1);
  for i = 1, #frustumpointset do
    --local point = frustumpointset[i];
    --newpoint:Set(point:x(),point:y(),point:z(),1);
    self.FrustumVertexStream:ChangeVertexDataWithAttributeFast(
      index_vertex,
      i,
      frustumpointset[i]);
  end
  self.FrustumVertexStream:SetReflushInterval(1, 8); --需要更新的数值索引区间 warp有-1的处理
  self.renderComponent:ChangeVertexBuffer(self.FrustumVertexStream); --缓存更新

end

------------------------------------------光照辅助体相关内容----------------------------------------------------

function LineNode:CreateLightGizmo(lightnode) --创建光照辅助体
  local lightcomponent = lightnode:GetComponent(apolloengine.Node.CT_LIGHT);
  self.lighttype = lightcomponent.LightType;
  self.renderComponent = self:CreateComponent(apolloengine.Node.CT_RENDER);
  self.renderComponent:EraseRenderProperty(apolloengine.RenderObjectEntity.RP_CULL);
  self.renderComponent:SetBindBox(mathfunction.Aabbox3d(mathfunction.vector3(0,0,0),mathfunction.vector3(0,0,0)));--无法被拾取
  self.FrustumVertexStream = apolloengine.VertexStream();  --初始化vertex
  self.FrustumVertexStream:SetVertexType(apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    apolloengine.VertexBufferEntity.DT_FLOAT,
    apolloengine.VertexBufferEntity.DT_HALF_FLOAT,
    3);
  self.FrustumIndexStream = apolloengine.IndicesStream();  --初始化index
  self.FrustumIndexStream:SetIndicesType(
  apolloengine.IndicesBufferEntity.IT_UINT16);
  self.FrustumVertexStream:ReserveBuffer(0);
  self.FrustumIndexStream:ReserveBuffer(0);
  self.pointnumpercirlce = 0;
  if self.lighttype == lightcomponent.LT_DIRECTIONAL then
    self:CreateDirectionLightGizmo(lightcomponent);  
  elseif self.lighttype == lightcomponent.LT_POINT then
    self:CreatePointLightGizmo(lightcomponent);
  elseif self.lighttype == lightcomponent.LT_SPOT then
    self:CreateSpotLightGizmo(lightcomponent);
  --elseif self.lighttype == lightcomponent.LT_AMBIENT then
  --  self:CreateAmbientLightGizmo(lightcomponent);
  end

  self.renderComponent:PushMetadata(
    apolloengine.RenderObjectMaterialMetadata(
      apolloengine.PathMetadata("comm:documents/material/gizmo.material")));
  local gridColor = apollocore.IMaterialSystem:NewParameterSlot(apollocore.ShaderEntity.UNIFORM,"POINT_COLOR");
  self.renderComponent:PushMetadata(
    apolloengine.RenderObjectMeshMetadate( 
      apolloengine.RenderObjectEntity.RM_LINES,
      apolloengine.ReferenceVertexMetadata(        
        apolloengine.VertexBufferEntity.MU_DYNAMIC,--使用可以修改的显存区域
        self.FrustumVertexStream),
      apolloengine.ReferenceIndicesMetadata(
        apolloengine.VertexBufferEntity.MU_DYNAMIC,--使用可以修改的显存区域   反射面板允许修改光类型 vertex  index 都需要改
        self.FrustumIndexStream)));

  self.renderComponent:CreateResource();
  self.renderComponent:SetParameter(gridColor,mathfunction.vector4(1.0,0.5,0.5,1.0));
  --self:AttachComponent(self.renderComponent);


end

function LineNode:CreateDirectionLightGizmo(lightcomponent)
  local lightpos = lightcomponent:GetWorldPosition();
  local lightup  = lightcomponent:GetWorldUp();
  local lightdir = lightcomponent:GetWorldDirection();
  local lightright = lightup:Cross(lightdir);
  self.pointnumpercirlce = 8;
  local tablez = self:GetCirclePoint(lightpos,lightright,lightup,self.pointnumpercirlce,0.1);
  for i = 1,#tablez do
    self.FrustumVertexStream:PushVertexData(
    apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    tablez[i]);
  end 
  for i = 1,#tablez do
    self.FrustumVertexStream:PushVertexData(
    apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    tablez[i]+lightdir);
  end
  

  for i = 0, #tablez-1 do
    self.FrustumIndexStream:PushIndicesData(i);
    if i == #tablez-1 then
      self.FrustumIndexStream:PushIndicesData(0);
    else
      self.FrustumIndexStream:PushIndicesData(i+1);
    end
  end
  for i = 0, #tablez-1 do
    self.FrustumIndexStream:PushIndicesData(i);
    self.FrustumIndexStream:PushIndicesData(i+#tablez);
  end
end

function LineNode:CreatePointLightGizmo(lightcomponent)
  local lightpos = lightcomponent:GetWorldPosition();
  local lightup  = mathfunction.vector3(0,1,0);
  local lightdir =mathfunction.vector3(0,0,1);
  local lightright = lightup:Cross(lightdir);
  self.pointnumpercirlce = 20;
  local range = lightcomponent:GetRange();
  local tablex = self:GetCirclePoint(lightpos,lightup,lightdir,self.pointnumpercirlce,range);
  local tabley = self:GetCirclePoint(lightpos,lightright,lightdir,self.pointnumpercirlce,range);
  local tablez = self:GetCirclePoint(lightpos,lightright,lightup,self.pointnumpercirlce,range);
  for i = 0,self.pointnumpercirlce-1 do
    self.FrustumVertexStream:PushVertexData(
    apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    tablex[i+1]);
    self.FrustumIndexStream:PushIndicesData(i);
    if i == self.pointnumpercirlce-1 then
      self.FrustumIndexStream:PushIndicesData(0);
    else
      self.FrustumIndexStream:PushIndicesData(i+1);
    end
  end
  for i = 0,self.pointnumpercirlce-1 do
    self.FrustumVertexStream:PushVertexData(
    apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    tabley[i+1]);
    self.FrustumIndexStream:PushIndicesData(i+self.pointnumpercirlce);
    if i == self.pointnumpercirlce-1 then
      self.FrustumIndexStream:PushIndicesData(self.pointnumpercirlce);
    else
      self.FrustumIndexStream:PushIndicesData(i+1+self.pointnumpercirlce);
    end
  end
  for i = 0,self.pointnumpercirlce-1 do
    self.FrustumVertexStream:PushVertexData(
    apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    tablez[i+1]);
    self.FrustumIndexStream:PushIndicesData(i+2*self.pointnumpercirlce);
    if i == self.pointnumpercirlce-1 then
      self.FrustumIndexStream:PushIndicesData(2*self.pointnumpercirlce);
    else
      self.FrustumIndexStream:PushIndicesData(i+1+2*self.pointnumpercirlce);
    end
  end
end

function LineNode:CreateSpotLightGizmo(lightcomponent)
  local lightpos = lightcomponent:GetWorldPosition();
  local lightup  = lightcomponent:GetWorldUp();
  local lightdir = lightcomponent:GetWorldDirection();
  local lightright = lightup:Cross(lightdir);
  self.pointnumpercirlce = 8;
  local spotangle = lightcomponent:GetLightAngle();
  local innerangle = spotangle:x()/2.0;
  local outerangle = spotangle:y()/2.0;
  local tablezin = self:GetCirclePoint(lightpos+lightdir,lightup,lightright,self.pointnumpercirlce,math.tan(innerangle));
  local tablezout = self:GetCirclePoint(lightpos+lightdir,lightup,lightright,self.pointnumpercirlce,math.tan(outerangle));
  for i = 0,self.pointnumpercirlce-1 do
    self.FrustumVertexStream:PushVertexData(
    apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    tablezin[i+1]);
    self.FrustumIndexStream:PushIndicesData(i);
    if i == self.pointnumpercirlce-1 then
      self.FrustumIndexStream:PushIndicesData(0);
    else
      self.FrustumIndexStream:PushIndicesData(i+1);
    end
  end
  for i = 0,self.pointnumpercirlce-1 do
    self.FrustumVertexStream:PushVertexData(
    apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    tablezout[i+1]);
    self.FrustumIndexStream:PushIndicesData(i+self.pointnumpercirlce);
    if i == self.pointnumpercirlce-1 then
      self.FrustumIndexStream:PushIndicesData(self.pointnumpercirlce);
    else
      self.FrustumIndexStream:PushIndicesData(i+1+self.pointnumpercirlce);
    end
  end
  self.FrustumVertexStream:PushVertexData(
    apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    lightpos);

  for i = 0,self.pointnumpercirlce-1 do
    self.FrustumIndexStream:PushIndicesData(i);
    self.FrustumIndexStream:PushIndicesData(self.pointnumpercirlce*2);
    self.FrustumIndexStream:PushIndicesData(i+self.pointnumpercirlce);
    self.FrustumIndexStream:PushIndicesData(self.pointnumpercirlce*2);
  end
end

--function LineNode:CreateAmbientLightGizmo(lightnode)
  --self.FrustumVertexStream:ReserveBuffer(0);
  --self.FrustumIndexStream:ReserveBuffer(0);
  -- body
--end

function LineNode:UpdateLightGizmo(lightnode)   --更新光照辅助体
  --"AmbientLight","DirectionLight","PointLight","SpotLight"
  local lightcomponent = lightnode:GetComponent(apolloengine.Node.CT_LIGHT);
  local lighttype = lightcomponent.LightType;

  if self.lighttype ~= lighttype then
    self.lighttype = lighttype;
    self.FrustumVertexStream:Clear();
    self.FrustumIndexStream:Clear();
    local newtexpath = nil;
    self.FrustumVertexStream:ReserveBuffer(0);
    self.FrustumIndexStream:ReserveBuffer(0);
    if self.lighttype == lightcomponent.LT_DIRECTIONAL then
      newtexpath = "comm:documents/texture/light/DirectionLight.png"; 
      self:CreateDirectionLightGizmo(lightcomponent); 
      self.renderComponent:SetDrawCount(self.pointnumpercirlce*4);
    elseif self.lighttype == lightcomponent.LT_POINT then
      newtexpath = "comm:documents/texture/light/PointLight.png"; 
      self:CreatePointLightGizmo(lightcomponent);  
      self.renderComponent:SetDrawCount(self.pointnumpercirlce*6);
    elseif self.lighttype == lightcomponent.LT_SPOT then  
      newtexpath = "comm:documents/texture/light/SpotLight.png"; 
      self:CreateSpotLightGizmo(lightcomponent);  
      self.renderComponent:SetDrawCount(self.pointnumpercirlce*8);  
    elseif self.lighttype == lightcomponent.LT_AMBIENT then 
      newtexpath = "comm:documents/texture/light/AmbientLight.png"; 
      self.pointnumpercirlce = 0;
      self.renderComponent:SetDrawCount(0);  
      --self:CreateAmbientLightGizmo(lightcomponent); 
    end
    lightnode:SetTexture(newtexpath);
    self.renderComponent:ChangeVertexBuffer(self.FrustumVertexStream); --渲染组件的顶点缓存更新  
    self.renderComponent:ChangeIndexBuffer(self.FrustumIndexStream); --渲染组件的索引缓存更新
    return                  --用于在反射面板切换光照类型
  end

  self.index_vertex = self.FrustumVertexStream:GetAttributeIndex(apolloengine.ShaderEntity.ATTRIBUTE_POSITION);
  if self.lighttype == lightcomponent.LT_DIRECTIONAL then
    self:UpdateDirectionLightGizmo(lightcomponent); 
  elseif self.lighttype == lightcomponent.LT_POINT then
    self:UpdatePointLightGizmo(lightcomponent);  
  elseif self.lighttype == lightcomponent.LT_SPOT then
    self:UpdateSpotLightGizmo(lightcomponent); 
  --elseif self.lighttype == lightcomponent.LT_AMBIENT then
  --  self:UpdateAmbientLightGizmo(lightcomponent);    
  end
  self.renderComponent:ChangeVertexBuffer(self.FrustumVertexStream); --缓存更新
end



function LineNode:UpdateDirectionLightGizmo(lightcomponent)
  local lightpos = lightcomponent:GetWorldPosition();
  local lightup  = lightcomponent:GetWorldUp();
  local lightdir = lightcomponent:GetWorldDirection();
  local lightright = lightup:Cross(lightdir);
  local tablez = self:GetCirclePoint(lightpos,lightright,lightup,self.pointnumpercirlce,0.1);
  for i = 1,#tablez do
    self.FrustumVertexStream:ChangeVertexDataWithAttributeFast(
    self.index_vertex,
    i,
    tablez[i]);
  end 
  for i = 1,#tablez do
    self.FrustumVertexStream:ChangeVertexDataWithAttributeFast(
    self.index_vertex,
    i+#tablez,
    tablez[i]+lightdir);
  end 
  self.FrustumVertexStream:SetReflushInterval(1, self.pointnumpercirlce*2); --需要更新的数值索引区间 warp有-1的处理
end

function LineNode:UpdatePointLightGizmo(lightcomponent)
  local lightpos = lightcomponent:GetWorldPosition();
  local lightup  = mathfunction.vector3(0,1,0);
  local lightdir =mathfunction.vector3(0,0,1);
  local lightright = lightup:Cross(lightdir);
  local range = lightcomponent:GetRange();
  local tablex = self:GetCirclePoint(lightpos,lightup,lightdir,self.pointnumpercirlce,range);
  local tabley = self:GetCirclePoint(lightpos,lightright,lightdir,self.pointnumpercirlce,range);
  local tablez = self:GetCirclePoint(lightpos,lightright,lightup,self.pointnumpercirlce,range);
  for i = 1,self.pointnumpercirlce do
    self.FrustumVertexStream:ChangeVertexDataWithAttributeFast(
    self.index_vertex,
    i,
    tablex[i]);
  end
  for i = 1,self.pointnumpercirlce do
    self.FrustumVertexStream:ChangeVertexDataWithAttributeFast(
    self.index_vertex,
    i+self.pointnumpercirlce,
    tabley[i]);
  end
  for i = 1,self.pointnumpercirlce do
    self.FrustumVertexStream:ChangeVertexDataWithAttributeFast(
    self.index_vertex,
    i+2*self.pointnumpercirlce,
    tablez[i]);
  end
  self.FrustumVertexStream:SetReflushInterval(1, self.pointnumpercirlce*3); --需要更新的数值索引区间 warp有-1的处理
end

function LineNode:UpdateSpotLightGizmo(lightcomponent)
  local lightpos = lightcomponent:GetWorldPosition();
  local lightup  = lightcomponent:GetWorldUp();
  local lightdir = lightcomponent:GetWorldDirection();
  local lightright = lightup:Cross(lightdir);
  local spotangle = lightcomponent:GetLightAngle();
  local innerangle = spotangle:x()/2.0;
  local outerangle = spotangle:y()/2.0;
  local tablezin = self:GetCirclePoint(lightpos+lightdir,lightup,lightright,self.pointnumpercirlce,math.tan(innerangle));
  local tablezout = self:GetCirclePoint(lightpos+lightdir,lightup,lightright,self.pointnumpercirlce,math.tan(outerangle));
  for i = 1,self.pointnumpercirlce do
    self.FrustumVertexStream:ChangeVertexDataWithAttributeFast(
    self.index_vertex,
    i,
    tablezin[i]);
  end
  for i = 1,self.pointnumpercirlce do
    self.FrustumVertexStream:ChangeVertexDataWithAttributeFast(
    self.index_vertex,
    i+self.pointnumpercirlce,
    tablezout[i]);
  end
  self.FrustumVertexStream:ChangeVertexDataWithAttributeFast(
    self.index_vertex,
    2*self.pointnumpercirlce+1,
    lightpos);
  self.FrustumVertexStream:SetReflushInterval(1, self.pointnumpercirlce*2+1); --需要更新的数值索引区间 warp有-1的处理
end

--function LineNode:UpdateAmbientLightGizmo()
--  LOG("update ambient");
  -- body
--end

function LineNode:GetCirclePoint(center,up,right,pointnum,size)
  local theta = math.pi*2.0/pointnum;
  local pointset = {};
  for i = 0,pointnum-1 do
    local point = center+up*math.sin(i*theta)*size+right*math.cos(i*theta)*size;
    table.insert(pointset,point);
  end
  return pointset;
end



function LineNode:SetShow(isShow)
  if self.isShow ~= isShow then
    self.isShow = isShow;
    if isShow then
      self.renderComponent:SetRenderProperty(apolloengine.RenderObjectEntity.RP_SHOW);
    else
      self.renderComponent:EraseRenderProperty(apolloengine.RenderObjectEntity.RP_SHOW);
    end  
  end
end




return LineNode