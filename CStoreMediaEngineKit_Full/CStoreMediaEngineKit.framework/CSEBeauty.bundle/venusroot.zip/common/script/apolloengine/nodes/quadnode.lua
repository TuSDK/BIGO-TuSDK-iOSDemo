local GenericNode = require "apolloengine.nodes.genericnode"
local apolloengine = require "apollocore"
local apollocore = require "apollocore"
local mathfunction = require "mathfunction"


local QuadNode = GenericNode:extend("QuadNode");

--0-------2   贴图位置三角形
--|	    / |
--|	  /   |
--| / 	  |
--1-------3    

--1-------3   纹理三角形
--|	    / |
--|	  /   |
--| / 	  |
--0-------2   
function QuadNode:new()
  QuadNode.super.new(self);
  self:SetLayer(apolloengine.LayerMask.MC_MASK_EDITOR_SCENE_LAYER);
end




function QuadNode:Create2DTexRenderComponent(materialpath,texturepath) --------------------2D贴图(node挂载一个rendercomponent)--------------
   

  self.rendercomponent = self:CreateComponent(apolloengine.Node.CT_RENDER);
  self.rendercomponent:SetBindBox(mathfunction.Aabbox3d(mathfunction.vector3(-0.05,-0.05,-0.05),mathfunction.vector3(0.05,0.05,0.05)));
  self.rendercomponent:PushMetadata(
    apollocore.RenderObjectMaterialMetadata(
      apollocore.PathMetadata(materialpath),
      apollocore.RenderObjectTextureMetadata(
        apollocore.ShaderEntity.TEXTURE_DIFFUSE,
        apollocore.TextureFileMetadata(
          apollocore.TextureEntity.TU_STATIC,
          apollocore.TextureEntity.PF_AUTO,
          1, true,
          apollocore.TextureEntity.TW_CLAMP_TO_EDGE,
          apollocore.TextureEntity.TW_CLAMP_TO_EDGE,
          apollocore.TextureEntity.TF_LINEAR,
          apollocore.TextureEntity.TF_LINEAR_MIPMAP_LINEAR,
        texturepath))));
  
  local vertexStream = apolloengine.VertexStream();
  vertexStream:SetVertexType(apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
    apolloengine.VertexBufferEntity.DT_FLOAT,
    apolloengine.VertexBufferEntity.DT_HALF_FLOAT,
    4);
  apolloengine.ShaderEntity.ATTRIBUTE_OFFSET = apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.ATTRIBUTE,"ATTRIBUTE_OFFSET");
  vertexStream:SetVertexType(apolloengine.ShaderEntity.ATTRIBUTE_OFFSET,
    apolloengine.VertexBufferEntity.DT_FLOAT,
    apolloengine.VertexBufferEntity.DT_HALF_FLOAT,
    2);
  vertexStream:SetVertexType(apolloengine.ShaderEntity.ATTRIBUTE_COORDNATE0,
    apolloengine.VertexBufferEntity.DT_FLOAT,
    apolloengine.VertexBufferEntity.DT_HALF_FLOAT,
    2);
  vertexStream:ReserveBuffer(4);--预先分配顶点的内存  4    每一个大写变量看做一个数组 里面有4个内容
  for i = 1,4 do
    vertexStream:PushVertexData(
        apolloengine.ShaderEntity.ATTRIBUTE_POSITION,
        mathfunction.vector4(0,0,0,1)); --
  end

  vertexStream:PushVertexData(
        apolloengine.ShaderEntity.ATTRIBUTE_OFFSET,
        mathfunction.vector2(-0.1,0.1));
  vertexStream:PushVertexData(
        apolloengine.ShaderEntity.ATTRIBUTE_OFFSET,
        mathfunction.vector2(-0.1,-0.1));
  vertexStream:PushVertexData(
        apolloengine.ShaderEntity.ATTRIBUTE_OFFSET,
        mathfunction.vector2(0.1,0.1));
  vertexStream:PushVertexData(
        apolloengine.ShaderEntity.ATTRIBUTE_OFFSET,
        mathfunction.vector2(0.1,-0.1));
  
  vertexStream:PushVertexData(
        apolloengine.ShaderEntity.ATTRIBUTE_COORDNATE0,
        mathfunction.vector2(0,0));
  vertexStream:PushVertexData(
        apolloengine.ShaderEntity.ATTRIBUTE_COORDNATE0,
        mathfunction.vector2(0,1));
  vertexStream:PushVertexData(
        apolloengine.ShaderEntity.ATTRIBUTE_COORDNATE0,
        mathfunction.vector2(1,0));
  vertexStream:PushVertexData(
        apolloengine.ShaderEntity.ATTRIBUTE_COORDNATE0,
        mathfunction.vector2(1,1));
  
  local indexStream = apolloengine.IndicesStream();
  indexStream:SetIndicesType(
    apolloengine.IndicesBufferEntity.IT_UINT16);
  indexStream:PushIndicesData(0);
  indexStream:PushIndicesData(1);
  indexStream:PushIndicesData(2);
  indexStream:PushIndicesData(1);
  indexStream:PushIndicesData(2);
  indexStream:PushIndicesData(3); 

  self.rendercomponent:PushMetadata(
    apolloengine.RenderObjectMeshMetadate( 
      apolloengine.RenderObjectEntity.RM_TRIANGLES,
      apolloengine.ReferenceVertexMetadata(        
        apolloengine.VertexBufferEntity.MU_STATIC,--使用不可以修改的显存区域 贴图位置会跟着父节点移动
        vertexStream),
      apolloengine.ReferenceIndicesMetadata(
        apolloengine.VertexBufferEntity.MU_STATIC,--使用不可修改的显存区域
        indexStream)));

  self.rendercomponent:CreateResource();
  --self.node:AttachComponent(self.rendercomponent); 

end

function QuadNode:SetParentNode(picknode) --用于拾取的特殊处理 以C++形式存储父节点  好像C++没有查找父节点的函数?
  self.parentnode = picknode.node;
end

function QuadNode:GetParentNode() 
  return self.parentnode;
end

function QuadNode:SetTexture(texpath)
  local tex = apolloengine.TextureEntity();
  tex:PushMetadata(apolloengine.TextureFileMetadata(
        apolloengine.TextureEntity.TU_STATIC,
        apolloengine.TextureEntity.PF_AUTO,1, false,
        apolloengine.TextureEntity.TW_CLAMP_TO_EDGE,
        apolloengine.TextureEntity.TW_CLAMP_TO_EDGE,
        apolloengine.TextureEntity.TF_NEAREST,
        apolloengine.TextureEntity.TF_NEAREST,
        texpath));
  --ktex:SetJobType(venuscore.IJob.JT_SYNCHRONOUS);
  tex:CreateResource();
  self.rendercomponent:SetParameter(apollocore.ShaderEntity.TEXTURE_DIFFUSE,tex)
end

return QuadNode;
