local apollocore = require "apollocore"


if _KRATOSEDITOR then
  local fbxfunc = require "fbxtool"

  local _fNativeOnSerializeStarted = apollocore.AnimationComponent.OnSerializeStarted;
  assert(_fNativeOnSerializeStarted);


  function apollocore.AnimationComponent:OnSerializeStarted()
      local saveInfos = self:GetSaveCurvesInfo();
      fbxfunc.FbxTool:AddAnimationSaveInfo(saveInfos);
  end
end