local apollocore = require "apollocore"
require "apolloengine.components"
require "apolloengine.enhance"


apollocore.GenericNode = require "apolloengine.nodes.genericnode"
apollocore.ParticleNode = require "apolloengine.nodes.particlenode"
apollocore.CameraNode = require "apolloengine.nodes.cameranode"



return apollocore;