
--debug和profiler不能同时开启，debug优先
--[[_DEBUG = true;
_PROFILER = false;
if _DEBUG and _PLATFORM_WINDOWS then
  local debuger = require "mobdebug/mobdebug";
  debuger.start();
  _COROUTINES_ON = debuger.on;
  _COROUTINES_OFF = debuger.off;
else
  _COROUTINES_ON = function() end;
  _COROUTINES_OFF = function() end;
end

if _PROFILER and _PLATFORM_WINDOWS and not _DEBUG then
  local count = 0
  local profiler = require "profiler"
  _PROFILER_START = function () profiler:start(); end
  _PROFILER_UPDATE = function ()
      count = count + 1;
      if count == 6000 then
        profiler:stop();
        profiler:writeReport('profiler.txt');
      end
    end
else
  _PROFILER_START = function() end;
  _PROFILER_UPDATE = function() end;
end  --]]  



local apolloengine = require "apolloengine"
local mathfunction = require "mathfunction"
local venuscore = require "venuscore"

local mlaa = {}
mlaa.Do = 0;
mlaa.Queue = 310;

function mlaa:Initialize(host, size)
  
  
  
  --_COROUTINES_ON();
  apolloengine.ShaderEntity.TEXTURE_DIFFUSE_POINT =
    apolloengine.IMaterialSystem:NewParameterSlot(
     apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_DIFFUSE_POINT");
    
    
      apolloengine.ShaderEntity.TEXTURE_NEIGHBOR_BLEND =
    apolloengine.IMaterialSystem:NewParameterSlot(
     apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_NEIGHBOR_BLEND");
    
      apolloengine.ShaderEntity.TEXTURE_AREAMAP =
    apolloengine.IMaterialSystem:NewParameterSlot(
     apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_AREAMAP");  

apolloengine.ShaderEntity.PIXEL_SIZE =     apolloengine.IMaterialSystem:NewParameterSlot(
     apolloengine.ShaderEntity.UNIFORM,
      "PIXEL_SIZE");  
    
    
  self:CreateInitVal(host,size);
 -- _COROUTINES_OFF();
  return self.Queue;
  
end


function mlaa:CreateInitVal(host,size)
  
  
  
  --local edgeDectionPath =  venuscore.IFileSystem:PathAssembly("ress:filter/resource/material/edgedetection.material");  
  local path ="comm:/documents";
  local edgeDectionPath = path.."/material/edgedetection.material";
  self.edgeDection = host:CreateRenderObject( edgeDectionPath);
  local tx = 1.0/size:x();
  local ty = 1.0/size:y();
  self.edgeDection:SetParameter(
    apolloengine.ShaderEntity.PIXEL_SIZE,
    mathfunction.vector2(tx,ty));
    
    
  --local simplePath =  venuscore.IFileSystem:PathAssembly("ress:filter/resource/material/simple.material");  
  --self.simplecopy= host:CreateRenderObject( simplePath);
  
 -- local  simplePathGamma=  venuscore.IFileSystem:PathAssembly("ress:filter/resource/material/simplegamma.material");  
   local  simplePathGamma=  path.."/material/simplegamma.material";
  self.simplecopygamma= host:CreateRenderObject( simplePathGamma);
  
  --local blendWeightPath = venuscore.IFileSystem:PathAssembly("ress:filter/resource/material/blendweight.material"); 
    local blendWeightPath = path.."/material/blendweight.material";
  
  self.blendweight = host:CreateRenderObject( blendWeightPath);
  
  
    self.blendweight:SetParameter(
    apolloengine.ShaderEntity.PIXEL_SIZE,
    mathfunction.vector2(tx,ty));
  
  --local neighborBlendPath = venuscore.IFileSystem:PathAssembly("ress:filter/resource/material/neighborblend.material"); 
   local neighborBlendPath = path.."/material/neighborblend.material";
  self.neighborblend = host:CreateRenderObject( neighborBlendPath);
  
    self.neighborblend:SetParameter(
   apolloengine.ShaderEntity.PIXEL_SIZE,
   mathfunction.vector2(tx,ty));
  
  local targetsize = size;

 self.Rt1 = host:CreateRenderTarget( apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,
    apolloengine.TextureRenderMetadata(
         apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,
        targetsize,apolloengine.TextureEntity.TF_LINEAR,apolloengine.TextureEntity.TF_LINEAR,0));
  
  
  
  self.Rt2 = host:CreateRenderTarget( apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,
    apolloengine.TextureRenderMetadata(
         apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,
        targetsize,apolloengine.TextureEntity.TF_NEAREST,apolloengine.TextureEntity.TF_NEAREST,0));
  
  self.Rt3 = host:CreateRenderTarget( apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,
          apolloengine.TextureRenderMetadata(
            apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,
            targetsize,
                  apolloengine.TextureEntity.TW_CLAMP_TO_EDGE,
                  apolloengine.TextureEntity.TW_CLAMP_TO_EDGE,
                  apolloengine.TextureEntity.TF_NEAREST,
                  apolloengine.TextureEntity.TF_NEAREST,0
          )
  );

  
    --self.Rt4 = host:CreateRenderTarget( apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,apolloengine.TextureRenderMetadata(
        -- apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,
        --targetsize,apolloengine.TextureEntity.TF_LINEAR,apolloengine.TextureEntity.TF_LINEAR,0));

    --self.Rt5 = host:CreateRenderTarget( apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,apolloengine.TextureRenderMetadata(
       --  apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,
       -- targetsize,apolloengine.TextureEntity.TF_NEAREST,apolloengine.TextureEntity.TF_NEAREST,0));
    
    --self.Rt6 = host:CreateRenderTarget( apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,apolloengine.TextureRenderMetadata(
        -- apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,
        --targetsize,apolloengine.TextureEntity.TF_LINEAR,apolloengine.TextureEntity.TF_LINEAR,0));
end


function mlaa:Resizeview(size)
  
  local tx = 1.0/size:x();
  local ty = 1.0/size:y();
  
   if( self.edgeDection )
   then
    self.edgeDection:SetParameter(
    apolloengine.ShaderEntity.PIXEL_SIZE,
    mathfunction.vector2(tx,ty));
  end
  
  if(self.blendweight)
  then
      self.blendweight:SetParameter(
    apolloengine.ShaderEntity.PIXEL_SIZE,
    mathfunction.vector2(tx,ty));
 end
  
  if(self.neighborblend)
  then
      self.neighborblend:SetParameter(
    apolloengine.ShaderEntity.PIXEL_SIZE,
    mathfunction.vector2(tx,ty));
  end
  
end



function mlaa:Process(pipeline, Original, Scene, Output)
  
  
    self.Rt3:PushRenderTarget();
    self.Rt3:ClearBuffer( apolloengine.RenderTargetEntity.CF_COLOR);
        self.simplecopygamma:SetParameter(
      apolloengine.ShaderEntity.TEXTURE_DIFFUSE,
      Original:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0));
    self.simplecopygamma:Draw(pipeline);
    
    
   
    self.Rt1:PushRenderTarget();
    self.Rt1:ClearBuffer( apolloengine.RenderTargetEntity.CF_COLOR);
    
    self.edgeDection:SetParameter(
      apolloengine.ShaderEntity.TEXTURE_DIFFUSE,
        self.Rt3:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0));
    --self.Do:SetParameter(
    --apolloengine.ShaderEntity.TEXTURE_DEPTHMAP,
    --Original:GetAttachment( apolloengine.RenderTargetEntity.TA_DEPTH_STENCIL));
    self.edgeDection:Draw(pipeline);
   
   
     
    self.Rt2:PushRenderTarget();
    self.Rt2:ClearBuffer( apolloengine.RenderTargetEntity.CF_COLOR);
    
    self.edgeDection:SetParameter(
      apolloengine.ShaderEntity.TEXTURE_DIFFUSE,
        self.Rt3:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0));
    --self.Do:SetParameter(
    --apolloengine.ShaderEntity.TEXTURE_DEPTHMAP,
    --Original:GetAttachment( apolloengine.RenderTargetEntity.TA_DEPTH_STENCIL));
    self.edgeDection:Draw(pipeline);
   
   
    self.Rt3:PushRenderTarget();
    self.Rt3:ClearBuffer( apolloengine.RenderTargetEntity.CF_COLOR);
    
    self.blendweight:SetParameter(
      apolloengine.ShaderEntity.TEXTURE_DIFFUSE,
      self.Rt1:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0));
    
    
    self.blendweight:SetParameter(
      apolloengine.ShaderEntity.TEXTURE_DIFFUSE_POINT,
      self.Rt2:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0));
    --self.Do:SetParameter(
    --apolloengine.ShaderEntity.TEXTURE_DEPTHMAP,
    --Original:GetAttachment( apolloengine.RenderTargetEntity.TA_DEPTH_STENCIL));
    self.blendweight:Draw(pipeline);
    
    
    
    
        self.Rt1:PushRenderTarget();
    self.Rt1:ClearBuffer( apolloengine.RenderTargetEntity.CF_COLOR);
        self.simplecopygamma:SetParameter(
      apolloengine.ShaderEntity.TEXTURE_DIFFUSE,
      Original:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0));
    self.simplecopygamma:Draw(pipeline);
  
  
  
    Output:PushRenderTarget();
    Output:ClearBuffer( apolloengine.RenderTargetEntity.CF_COLOR);
    
    self.neighborblend:SetParameter(
    apolloengine.ShaderEntity.TEXTURE_DIFFUSE,
    self.Rt1:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0));
    

    self.neighborblend:SetParameter(
    apolloengine.ShaderEntity.TEXTURE_NEIGHBOR_BLEND,
    self.Rt3:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0));
    self.neighborblend:Draw(pipeline);
    
    

end

return mlaa;
