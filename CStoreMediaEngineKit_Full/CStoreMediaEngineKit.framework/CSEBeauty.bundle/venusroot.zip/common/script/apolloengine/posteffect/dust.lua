local apolloengine = require "apolloengine"
local mathfunction = require "mathfunction"
local venuscore = require "venuscore"

local dust = {}
dust.Dn = 0;
dust.Queue = 100;


function dust:Initialize(host, size)  
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"FRAME_SIZE");
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"CUR_FRAME_ID");
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"SAMPLE_SIZE"); 
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"RESOLUTION"); 
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"ROW_FRAME_NUM_PER_TEX"); 
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"COL_FRAME_NUM_PER_TEX");   
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"HISTORICAL_FRAME1");  
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"HISTORICAL_FRAME2");  
  apolloengine.IMaterialSystem:NewParameterSlot(
     apolloengine.ShaderEntity.UNIFORM,"HISTORICAL_FRAME3");  
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"HISTORICAL_FRAME4");
  apolloengine.IMaterialSystem:NewParameterSlot(
    apolloengine.ShaderEntity.UNIFORM,"HISTORICAL_FRAMES");
  apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,"NOISE_TEXTURE");
  local pathout = venuscore.IFileSystem:PathAssembly("docs:material/dust.material");  
  self.Do = host:CreateRenderObject(pathout);
  return self.Queue;
end

function dust:Resizeview(size)
end

function dust:Process(pipeline, Original, Scene, Output)
  Output:PushRenderTarget();
  Output:ClearBuffer( apolloengine.RenderTargetEntity.CF_COLOR );
  --[[self.Do:SetParameter(
		apolloengine.ShaderEntity.TEXTURE_DIFFUSE,
		Scene:GetAttachment( apolloengine.RenderTargetEntity.TA_COLOR_0 ) );]]--
	self.Do:Draw(pipeline);
end

return dust;