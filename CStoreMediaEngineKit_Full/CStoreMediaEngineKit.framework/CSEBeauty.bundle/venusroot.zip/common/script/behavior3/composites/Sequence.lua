local b3 = require 'behavior3.b3';
require 'behavior3.core.Composite'

local sequence = b3.Class("Sequence", b3.Composite)
b3.Sequence = sequence

function sequence:ctor()
	b3.Composite.ctor(self)

	self.name = "Sequence"
end

function sequence:tick(tick)
	for i,v in ipairs(self.children) do
		local status = v:_execute(tick)
		--print(i,v)
		if status ~= b3.SUCCESS then
			return status
		end
	end
	return b3.SUCCESS
end
