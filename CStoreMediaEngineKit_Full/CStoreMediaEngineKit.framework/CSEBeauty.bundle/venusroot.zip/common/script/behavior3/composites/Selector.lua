local b3 = require 'behavior3.b3';
require 'behavior3.core.Composite'

local selector = b3.Class("Selector", b3.Composite)
b3.Selector = selector

function selector:ctor()
	b3.Composite.ctor(self)
	
	self.name = "Selector"
end

function selector:tick(tick)
	for i,v in ipairs(self.children) do
		local status = v:_execute(tick)
	end
end
