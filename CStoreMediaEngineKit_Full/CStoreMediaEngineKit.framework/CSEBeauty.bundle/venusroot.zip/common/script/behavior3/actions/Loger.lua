local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'
require 'utility'

local loger = b3.Class("Loger", b3.Action)
b3.Loger = loger

function loger:ctor()
	b3.Action.ctor(self)	
	self.name = "Loger"
end

function loger:tick()
  LOG(self.properties.content);
	return b3.SUCCESS;
end
