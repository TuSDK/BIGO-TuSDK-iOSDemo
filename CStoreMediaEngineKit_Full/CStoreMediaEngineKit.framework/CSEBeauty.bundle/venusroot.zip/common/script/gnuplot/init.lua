require 'torch'

gnuplot = {}
require('gnuplot.gnuplot')
require('gnuplot.hist')

return gnuplot
