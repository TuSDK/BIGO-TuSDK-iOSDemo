local BundleSystem = require "venuscore.bundle.bundlesystem"
local renderqueue = require "apolloutility.renderqueue"
local apollonode = require "apolloutility.apollonode"
local defined = require "apolloutility.defiend"
local mathfunction = require "mathfunction"
local apolloengine = require "apollocore"
local videodecet = require "videodecet"
local venuscore = require "venuscore"
local venusjson = require "venusjson"
local editorscene = {}

function editorscene:Initialize(camera)
  self.maincamera = camera;
  self.objects = {};
  self.objectPaths = {};
  
  self.firstCamera = nil;
  self.sceneCamers = {};
  self.aniComponents = {};
  self.frameaniComponents = {};
  self.renderComponents = {};
  self.cpuEmitter = nil;
  
  self.inputtex = nil; --上层layer的结果
  self.outputtex = nil; -- 编辑器场景结果
  self.mainrt = nil; 
  self.newsequnces = {}; --renderqueue排序后结果
  self.firstquadnode = nil;

  --self.objectUsrscripts = {};
end

function editorscene:Update(def)
  
  --[[for key, value in pairs(self.objectUsrscripts) do
    value:Update(def);
  end]]--
    
  for k,v in pairs(self.objects) do 
    if v.Update then
      v:Update(def)
    end
  end
  
end

function editorscene:LoadConfig(path)
  local rootconfig = venusjson.LaodJsonFile(path);
  if rootconfig.scene then    
    local pathDir= string.match(path, "(.+)/[^/]*%.%w+$");
    local rootdir = pathDir.."/"; 
    venuscore.IFileSystem:SetResourcePath(rootdir);
    local baseobject = self:CreateInstanceFromBundle(venuscore.IFileSystem:PathAssembly(rootconfig.scene));
    for i = 1, #baseobject do
      local nativeNode = baseobject[i]:GetNativeNode();
      local nodeType = baseobject[i]:GetTypeName();
      --self.objects[path][tostring(nativeNode:GetObjectID())] = baseobject[i];
      self.objects[tostring(nativeNode:GetObjectID())] = baseobject[i];
      self.objectPaths[tostring(nativeNode:GetObjectID())] = path;
      
      if nodeType == "ParticleNode" then
        local rendercom = baseobject[i].RenerComponent;
        if rendercom then
          table.insert(self.renderComponents,rendercom)
        end
        self.cpuEmitter = baseobject[i]:GetNativeNode();
      else
        local cameracom = baseobject[i]:GetComponent(apolloengine.Node.CT_CAMERA);
        if cameracom then
          if self.firstCamera == nil or (self.firstCamera).Sequence > cameracom.Sequence then
            self.firstCamera = cameracom;
          end
          self.sceneCamers[cameracom.Sequence] = cameracom;
        end
        
        local rendercom = baseobject[i]:GetComponent(apolloengine.Node.CT_RENDER)
        if rendercom then
          table.insert(self.renderComponents,rendercom)
        end

        local frameanicom = baseobject[i]:GetComponent(apolloengine.Node.CT_FRAMEANI_COMPONENT)
        if frameanicom then
          table.insert(self.frameaniComponents,frameanicom);
        end
        
        local animationcom = baseobject[i]:GetComponent(apolloengine.Node.CT_ANIMATION)
        if animationcom then
          table.insert(self.aniComponents,animationcom);
        end
      end
    end
    self:_CameraInit();
    self:_RenderInit();
    self:_FramAniInit();
    self:_ParticleInit();
    self:_AnimationInit();
  end
  return true;
end

function editorscene:CreateInstanceFromBundle(path)
  local bundlepath = venuscore.IFileSystem:PathAssembly(path);
  local file = io.open(bundlepath, "rb");
  local str = file:read("*a");
  return BundleSystem:DeSerialize(str);
end

function editorscene:_CameraInit()
  
  local color = mathfunction.Color(1.0,0.5,0.5,1);
  self.mainrt =  apolloengine.RenderTargetEntity();--创建一个FBO
  self.mainrt:PushMetadata(--设置FBO格式
                apolloengine.RenderTargetMetadata(
                  apolloengine.RenderTargetEntity.RT_RENDER_TARGET_2D,
                  apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,--标记作用，主要用于底层资源共享
                  color,--清屏颜色
                  apolloengine.Framework:GetViewport(),
                  apolloengine.Framework:GetResolution()));--分辨率
  self.mainrt:MakeBufferAttachment(apolloengine.RenderTargetEntity.TA_DEPTH_STENCIL);--增加color0纹理
  self.outputtex = self.mainrt:MakeTextureAttachment(apolloengine.RenderTargetEntity.TA_COLOR_0);--增加color0纹理
  self.outputtex:PushMetadata(--创建纹理
                apolloengine.TextureRenderMetadata(
                  apolloengine.RenderTargetEntity.ST_SWAP_UNIQUE,--此处的纹理swap和尺寸必须和rt的相同不然将导致未定义的错误
                  apolloengine.Framework:GetResolution()));
  self.mainrt:CreateResource();
  
  
  --没有fbo的相机
  local inputcameras = {};
  for key,value in pairs (self.sceneCamers) do
    if value:GetAttachedRenderTarget() == nil then
      value:AttachRenderTarget(self.mainrt);
    end
    table.insert(inputcameras,value);
  end
  
  --回调函数
  self.SettingInputTexture = function(texture)
    self.inputtex = texture;
  end
  
  self.GettingOutputTexture = function()
    local outtex = self.outputtex
    return outtex;
  end
  
  self.SettingSequences = function(sequences)
    self.newsequnces = sequences;
  end
  
  --编辑器相机队列插入renderqueue相机队列
  renderqueue:InsertCameras(renderqueue.CAMERA_LAYER_FIRST,inputcameras,self.SettingInputTexture,self.GettingOutputTexture,self.SettingSequences);
  --第一个相机的输入
  self.firstquadnode = apollonode.QuadNode();
  self.firstquadnode:SetShow(true);
  self.firstquadnode:CreateResource(defined.blit_material_path,true,false);
  self.firstquadnode:SetSequence(self.newsequnces[1]);
  self.firstquadnode:SetParameter(apolloengine.ShaderEntity.TEXTURE_DIFFUSE,self.inputtex);
  
end

function editorscene:_RenderInit()
  for key,value in pairs (self.renderComponents) do
    local orisequence = value:GetSequence();
    local newsequence = (self.sceneCamers[orisequence]).Sequence;
    value:SetSequence(newsequence);
  end
end

function editorscene:_FramAniInit()
  for key,value in pairs (self.frameaniComponents) do
    value:Play();
  end
end

function editorscene:_ParticleInit()
  if self.cpuEmitter then
    self.cpuEmitter:Start();
  end
end

function editorscene:_AnimationInit()
    for key,value in pairs(self.aniComponents) do
      local animations = value:GetAnimations();
      for k,v in pairs(animations) do
        value:Play(k); 
        value:Loop(k,true);
      end
    end
end


function editorscene:ReleaseResource()

  --[[for key, value in pairs(self.objectUsrscripts) do
    value:ReleaseResource();
  end]]--
  --self.objectUsrscripts = {};
  
  self.objects = {};
  self.objectPaths = {};
  
  self.firstCamera = nil;
  self.sceneCamers = {};
  self.aniComponents = {};
  self.frameaniComponents = {};
  self.renderComponents = {};
  self.cpuEmitter = nil;
  
  self.outputtex =  nil;
  self.inputtex = nil;
  self.mainrt = nil;
  self.firstquadnode = nil;
  self.newsequnces = nil;
  
  self.SettingInputTexture = nil;
  self.GettingOutputTexture = nil;
  self.SettingSequences = nil;
  
  renderqueue:InsertCameras(nil,nil,self.SettingInputTexture,self.GettingOutputTexture,self.SettingSequences);
  collectgarbage();
end

function editorscene:OnRecordStart()
  if not self.frameaniComponents or not self.aniComponents then
    return
  end
  
  for key,value in pairs (self.frameaniComponents) do
    value:Reset();
  end
  
  for key,value in pairs(self.aniComponents) do
    local animations = value:GetAnimations();
    for k,v in pairs(animations) do
      value:Reset(k); 
    end
  end
  
  if self.cpuEmitter then
    self.cpuEmitter:Reset();
  end
end


return editorscene;