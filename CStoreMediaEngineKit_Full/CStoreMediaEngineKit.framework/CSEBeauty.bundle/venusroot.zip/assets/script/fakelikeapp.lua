

local likeapp = {}

likeapp.AI = {}

function likeapp.AI:RefreshedRawarray()
  return true
end

function likeapp.AI:GetRawarray()
  return {}
end

function likeapp.AI:ActiveActions()
  return {}
end

function likeapp.AI:GetFaceVisibility()
  return {}
end

function likeapp.AI:PushNewFaceLandMark(input)

end

return likeapp