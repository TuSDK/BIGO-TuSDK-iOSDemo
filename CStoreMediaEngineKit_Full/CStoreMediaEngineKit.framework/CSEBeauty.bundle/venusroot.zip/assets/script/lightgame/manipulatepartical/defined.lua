local defined = {
  max_head_target_count = 3,
  soundType={SoundDectect=1,SoundSilence=2},
  soundLoopCount={SoundDetectLoop=1,SoundSilenceLoop=0},
}
return defined;