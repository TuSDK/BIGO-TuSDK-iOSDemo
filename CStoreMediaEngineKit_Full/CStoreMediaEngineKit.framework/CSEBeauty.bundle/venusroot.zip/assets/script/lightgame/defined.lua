local defined = {
  max_head_target_count = 3,
}
return defined;