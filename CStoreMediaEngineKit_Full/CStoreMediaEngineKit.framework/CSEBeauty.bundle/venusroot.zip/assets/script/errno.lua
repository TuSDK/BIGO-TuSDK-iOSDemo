
local errno =
{
   SUPERME_FILE_NO_EXIT = 1 ;
   SUPERME_FRAME_IDX_NIL = 2;
   SUPERME_KEY_POINT_FILE_NAME_ERROR = 3;
   SUPERME_MASK_ID_NIL = 4 ;
   JUST_FOR_DEBUG_TEST = 5 ; -- 用于调试的错误码

}

return errno ;