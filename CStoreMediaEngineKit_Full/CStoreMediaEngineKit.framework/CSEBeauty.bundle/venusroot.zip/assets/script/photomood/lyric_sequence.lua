if _PLATFORM_WINDOWS then
  return require "photomood.lyric_sequence_windows"
elseif _PLATFORM_ANDROID then
  return require "photomood.lyric_sequence_mobile"
elseif _PLATFORM_IOS then
  return require "photomood.lyric_sequence_mobile"
end