
--默认配置
local biugodefined = 
{
  photomood_mask_clip_camera_sequence = -3000,  --用于对用户图片进行裁剪的相机
  photomood_base_blend_camera_sequence = -2900, --用于base视频采用overly等混合方式时
  mask_background_blit_material_path = "docs:photomood/material/mask_background.material",
  mask_clip_material_path = "docs:photomood/material/mask_clip.material",
  cover_background_material_path = "docs:photomood/material/cover_background.material",
  cover_before_material_path = "docs:photomood/material/cover_before.material",
  cover_material_path = "docs:photomood/material/cover.material",
  mask_video_material_path = "docs:photomood/material/mask_video.material",
  base_video_material_path = "docs:photomood/material/base_vadieo.material",
  --下面的为windows测试
  windows_mask_sequence_path = "comm:documents/mask/",
  windows_mask_sequence_name = "%04d.jpg",
  windows_custom_texture_path = "comm:documents/customtexture/",
  windows_custom_texture_name = "0374.png",
  windows_lyric_texture_path = "comm:documents/customtexture/",
  windows_lyric_texture_name = "output3.png",
  
  base_material_begin = [[
    #include "docs:photomood/material/shaders/base_video.shader"

    #LIGHTING_AMBIENT_FORWARD_SINGLE		BaseVideoMaterial 
    #LIGHTING_DIRECTION_FORWARD_SINGLE	BaseVideoMaterial 
    #LIGHTING_POINT_FORWARD_SINGLE 			BaseVideoMaterial 
    #LIGHTING_SPOT_FORWARD_SINGLE 			BaseVideoMaterial 
                                                              
    #MATERIAL_DEFINE BaseVideoMaterial 
      RENDER_QUEUE = %s
      COLOR_MASK = COLOR_RGBA 
      ALPAH_MODE = %s
      DRAW_MODE = { CULL_FACE_OFF, DEPTH_MASK_OFF, DEPTH_TEST_ON, DEPTH_FUNCTION_LESS } 
      STENCIL_MODE = {STENCIL_OFF}]];
  
  material_begin = [[
                      #include "docs:photomood/material/shaders/mask_video.shader"
                      #include "docs:photomood/material/shaders/easing.shader"
                      #include "docs:photomood/material/shaders/positioneasing.shader"
                      #include "docs:photomood/material/shaders/scaleeasing.shader"
                      #include "docs:photomood/material/shaders/alphaeasing.shader"
                      #include "docs:photomood/material/shaders/sliceeasing.shader"
                      #include "docs:photomood/material/shaders/cutverticaleasing.shader"
                      #include "docs:photomood/material/shaders/cuthorizontaleasing.shader"
                      #include "docs:photomood/material/shaders/ktveasing.shader"
                      #include "docs:photomood/material/shaders/rotateeasing.shader"
                      #include "docs:photomood/material/shaders/tween.shader"
                                                                             
                      #LIGHTING_AMBIENT_FORWARD_SINGLE		PotoMoodMaterial 
                      #LIGHTING_DIRECTION_FORWARD_SINGLE	PotoMoodMaterial 
                      #LIGHTING_POINT_FORWARD_SINGLE 			PotoMoodMaterial 
                      #LIGHTING_SPOT_FORWARD_SINGLE 			PotoMoodMaterial
                                                                                
                      #MATERIAL_DEFINE PotoMoodMaterial 
                        RENDER_QUEUE = %s
                        COLOR_MASK = COLOR_RGBA 
                        ALPAH_MODE = %s
                        DRAW_MODE = { CULL_FACE_OFF, DEPTH_MASK_OFF, DEPTH_TEST_ON, DEPTH_FUNCTION_LESS } 
                        STENCIL_MODE = {STENCIL_OFF}]];
  material_end = "#END_DEFINE";
  
  AlphaMode = 
  {
      Blend = "{ ALPAH_BLEND, SRC_ALPHA, ONE_MINUS_SRC_ALPHA , ONE, ONE }",
      Add = "{ ALPAH_BLEND, ONE, ONE , ONE, ONE }"
  },
  BlendMode = 
  {
      Overlay = "comm:script/apolloengine/posteffect/blend_overlay.lua",
      Screen = "comm:script/apolloengine/posteffect/blend_screen.lua",
      SoftLight = "comm:script/apolloengine/posteffect/blend_softlight.lua"
  },
  Shaders = 
  {
      Simple = [[
       	VERTEX_SHADER = 
        {
          "MaskVideoVertex"
        }
        FRAGMENT_SHADER = 
        {
          "MaskVideoFragment"
        }
      ]],
      SimpleV2 = [[
       	VERTEX_SHADER = 
        {
          "MaskVideoVertex"
        }
        FRAGMENT_SHADER = 
        {
          "MaskVideoFragment_Version2"
        }
      ]],
      --加入LUT
      SimpleV3 = [[
        VERTEX_SHADER = 
        {
          "MaskVideoVertex"
        }
        FRAGMENT_SHADER = 
        {
          "MaskVideoFragment_Version3"
        }
      ]],
      BaseVideo = [[
        VERTEX_SHADER = 
        {
          "BaseVideoVertex"
        }
        FRAGMENT_SHADER = 
        {
          "BaseVideoFragment"
        }
      ]]
  },
  FilterName_to_Path = 
  {
      lut = "comm:script/apolloengine/posteffect/lut.lua",
      hald_lut = "comm:script/apolloengine/posteffect/hald_lut.lua",
      tunes = "comm:script/apolloengine/posteffect/tunes.lua",
      laplacesharp = "comm:script/apolloengine/posteffect/laplacesharp.lua",
      rgbseperate = "comm:script/apolloengine/posteffect/rgbseperate.lua",
      alphachange = "comm:script/apolloengine/posteffect/alphachange.lua",
      fastblur = "comm:script/apolloengine/posteffect/fastblur.lua",
      radialblur = "comm:script/apolloengine/posteffect/radialblur.lua",
      hsladj = "comm:script/apolloengine/posteffect/hsladj.lua",
      invert = "comm:script/apolloengine/posteffect/invert.lua",
      comic = "comm:script/apolloengine/posteffect/comic.lua",
      mosaic = "comm:script/apolloengine/posteffect/mosaic.lua"
  },

  Lyric_Config_Default =
  {
    OutlineColor = {0,0,0,1},
    OulineOffset = {1,-1,0,0},
    InEffect = {
      DurationPercent = 20,
      Attributes = {
        {
          Name = "Alpha",
          Interpolation = "Linear",
          StartV = {0},
          EndV = {1}
        }
      }
    },
    OutEffect = {
      DurationPercent = 20,
      Attributes = {
        {
          Name = "Alpha",
          Interpolation = "Linear",
          StartV = {1},
          EndV = {0}
        }
      }
    }
  },
  Quotation_Config_Default =
  {
    OutlineColor = {0,0,0,1},
    OulineOffset = {1,-1,0,0},
    InEffect = {
      DurationPercent = 20,
      Attributes = {
        {
          Name = "Alpha",
          Interpolation = "Linear",
          StartV = {0},
          EndV = {1}
        }
      }
    },
    OutEffect = {
      DurationPercent = 20,
      Attributes = {
        {
          Name = "Alpha",
          Interpolation = "Linear",
          StartV = {1},
          EndV = {0}
        }
      }
    }
  }

}



return biugodefined;