  
local basedetect = require "videodecet.basevideodetect";
local apollonode = require "apolloutility.apollonode"
local renderqueue = require "apolloutility.renderqueue"
local defiend = require "apolloutility.defiend"
local apolloengine = require "apolloengine"
local mathfunction = require "mathfunction"
local MaskRender = require "photomood.mask_render"
local LyricRender = require "photomood.lyric_render"
local venuscore = require "venuscore"
local videodecet = require "videodecet"
local biugodefined = require "photomood.defined"
local emptyimage = require "apolloutility.emptyimage"
local stringsplit = require "stringsplit"
local SquareInfo = require "photomood.squareinfo";
local PostEffectRender = require "photomood.posteffect_render"
local Object = require "classic"
local likeapp = require "likeapp"





local MainCameraSequence = Object:extend();

function MainCameraSequence:new(material_list,track_list)
  self.posteffector_render = PostEffectRender(material_list,track_list,"maincamera"); --创建后处理渲染
end

function MainCameraSequence:Update()
  local frameInd = likeapp.AI:GetFrameIndex();
  frameInd = frameInd + 1; --与rect的渲染保持一致，rect文件是从1开始的，在posteffector_render中会将帧好减1
  self.posteffector_render:Update(frameInd);
end

return MainCameraSequence;
