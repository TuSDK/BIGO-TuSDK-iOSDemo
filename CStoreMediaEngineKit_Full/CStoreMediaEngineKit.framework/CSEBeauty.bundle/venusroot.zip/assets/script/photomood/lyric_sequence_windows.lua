local SequenceAnimation = require "apolloutility.sequenceanimation"
local basedetect = require "videodecet.basevideodetect";
local apollonode = require "apolloutility.apollonode"
local renderqueue = require "apolloutility.renderqueue"
local defiend = require "apolloutility.defiend"
local apolloengine = require "apolloengine"
local mathfunction = require "mathfunction"
local LyricSequenceBase = require "photomood.lyric_sequence_base"
local venuscore = require "venuscore"
local videodecet = require "videodecet"
local biugodefined = require "photomood.defined"
local asynctexture = require "apolloutility.asynctexture.asynctexture"
local Object = require "classic"



local LyricSequence = LyricSequenceBase:extend();
--[[
function LyricSequence:new(lyricMaterialName,lyricAlphaMode,lyricInterpolate,lyricPreDuration,lyricPostDuration)
  LyricSequence.super.new(self,lyricMaterialName,lyricAlphaMode,lyricInterpolate,lyricPreDuration,lyricPostDuration);
  
  --windows 测试
  local lyric_tex = apolloengine.TextureEntity();
  lyric_tex:PushMetadata(
    apolloengine.TextureFileMetadata(biugodefined.windows_lyric_texture_path .. biugodefined.windows_lyric_texture_name));
  lyric_tex:SetJobType(venuscore.IJob.JT_SYNCHRONOUS);
  lyric_tex:CreateResource();
  self.lyric_texture = lyric_tex;
  self.lyric_location = {0,0};
  self.lyric_texture_size = {0.5,0.2}
  self.lyric_show_time = 10;
  self.lyric_acc_time = 0.0;
  self.progress_pre = 0.0;
  self.progress_post = 0.0;
  
  self.lyricrender:SetRenderRect(self.lyric_location,self.lyric_texture_size);
    
  self:SetShow(true); --开启绘制
end
--]]
function LyricSequence:new(inEffect,outEffect,outline_Color,outline_Offset)
  LyricSequence.super.new(self,inEffect,outEffect,outline_Color,outline_Offset);
  
  --windows 测试
  local lyric_tex = apolloengine.TextureEntity();
  lyric_tex:PushMetadata(
    apolloengine.TextureFileMetadata(
          biugodefined.windows_lyric_texture_path .. biugodefined.windows_lyric_texture_name));
  lyric_tex:SetJobType(venuscore.IJob.JT_SYNCHRONOUS);
  lyric_tex:CreateResource();
  
  

  
  
  self.lyric_texture = lyric_tex;
  self.lyric_location = {0,0};
  self.lyric_texture_size = {1.0,0.2};
  self.lyric_color = {255.0,0.0,0.0};
  self.lyric_show_time = 10;
  self.lyric_acc_time = 0.0;
  self.progress_pre = 0.0;
  self.progress_post = 0.0;
  
  self.lyricrender:SetRenderRect(self.lyric_location,self.lyric_texture_size,self.lyric_color,self.useOriginColor);
    
  self:SetShow(true); --开启绘制
end

function LyricSequence:Update(timespan)
    
  LyricSequence.super.Update(self,timespan);
end

function LyricSequence:SetLyric(lyricTextureID,lyricColor,lyricDuration,lyricSize,lyricPosition,isNew, useOriginColor)
end



return LyricSequence;


