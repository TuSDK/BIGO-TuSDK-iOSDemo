local apolloengine = require "apolloengine"

local pbrlighting = {}
--对PBR材质中的贴图的slot进行初始化
function pbrlighting:Initialize()

  apolloengine.ShaderEntity.SKY_BOX = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"SKY_BOX");
  
  apolloengine.ShaderEntity.TEXTURE_ALDEBO = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TEXTURE_ALDEBO");

  apolloengine.ShaderEntity.TEXTURE_NORMAL = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TEXTURE_NORMAL");

  apolloengine.ShaderEntity.TEXTURE_METALLIC = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TEXTURE_METALLIC");

  apolloengine.ShaderEntity.TEXTURE_ROUGHNESS = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TEXTURE_ROUGHNESS");
  
  apolloengine.ShaderEntity.TEXTURE_AMR = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TEXTURE_AMR");

  --世界空间转到切线空间的矩阵
  apolloengine.ShaderEntity.W2T_TBN_MAT = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"W2T_TBN_MAT");

  --切线空间转到世界空间的矩阵
  apolloengine.ShaderEntity.T2W_TBN_MAT = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"T2W_TBN_MAT");

  apolloengine.ShaderEntity.ALBEDO_COLOR = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"ALBEDO_COLOR");

  apolloengine.ShaderEntity.METALLIC_VALUE = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"METALLIC_VALUE");

  apolloengine.ShaderEntity.ROUGHNESS_VALUE = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"ROUGHNESS_VALUE");

  apolloengine.ShaderEntity.TANGENTSPACE_NORMAL = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TANGENTSPACE_NORMAL");
  --基础反射色
  apolloengine.ShaderEntity.Base_Reflectivity = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"Base_Reflectivity");


  apolloengine.ShaderEntity.IBL_DIFFUSE_COLOR = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"IBL_DIFFUSE_COLOR");


  apolloengine.ShaderEntity.IBL_SPECULAR_COLOR = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"IBL_SPECULAR_COLOR");



end

return pbrlighting;
