local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local physicsdisable = b3.Class("DisablePhysics", b3.Action)

function physicsdisable:ctor()
	b3.Action.ctor(self)	
	self.name = "DisablePhysics"
end

function physicsdisable:tick(tick)
    local physicsscope = tick.blackboard:get("physicsscope");
    if physicsscope~=nil then
       physicsscope:DisablePhysics();
    end
    return b3.SUCCESS;
end

return physicsdisable;