local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local modelhide = b3.Class("ModelSetHide", b3.Action)

function modelhide:ctor()
	b3.Action.ctor(self)	
	self.name = "ModelSetHide";
end

function modelhide:tick(tick)
  local model = tick.blackboard:get("modelscope");
  model:SetShow(false);
  return b3.SUCCESS;
end

return modelhide;