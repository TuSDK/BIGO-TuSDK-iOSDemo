local b3 = require 'behavior3.b3';
require 'behavior3.core.Decorator'

local isrunning = b3.Class("isRunning", b3.Decorator)

function isrunning:ctor()
  b3.Decorator.ctor(self)
	self.name = "isRunning"
end

function isrunning:tick(tick)
	if not self.child then
		return b3.ERROR
	end
	local status = self.child:_execute(tick)
  
	if status == b3.RUNNING then
		status = b3.SUCCESS
	end
	return status
end

return isrunning;