local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local modelshow = b3.Class("ModelSetShow", b3.Action)

function modelshow:ctor()
	b3.Action.ctor(self)	
	self.name = "ModelSetShow"
end

function modelshow:tick(tick)
  local model = tick.blackboard:get("modelscope");
  model:SetShow(true);
  return b3.SUCCESS;
end

return modelshow;