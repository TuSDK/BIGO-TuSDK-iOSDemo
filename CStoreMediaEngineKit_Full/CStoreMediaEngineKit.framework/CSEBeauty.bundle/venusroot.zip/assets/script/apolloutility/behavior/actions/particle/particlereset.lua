local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local particlereset = b3.Class("ParticleReset", b3.Action)

function particlereset:ctor()
	b3.Action.ctor(self)	
	self.name = "ParticleReset";
end

function particlereset:tick(tick)
  local particles = tick.blackboard:get("particlescope");
  for _,p in ipairs(particles) do
    p:Reset();
  end
  return b3.SUCCESS;
end

return particlereset;