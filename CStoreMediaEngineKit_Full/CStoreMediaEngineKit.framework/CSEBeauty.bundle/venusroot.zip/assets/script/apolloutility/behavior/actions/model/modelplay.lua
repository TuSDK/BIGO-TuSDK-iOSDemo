local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local modelplay = b3.Class("ModelPlay", b3.Action)

function modelplay:ctor()
	b3.Action.ctor(self)	
	self.name = "ModelPlay"
end

function modelplay:tick(tick)
  local model = tick.blackboard:get("modelscope");
  local fb = self.properties.framebegin;
  local fe = self.properties.frameend;
  local loop = self.properties.loop == "true";
  model:SetLoop(loop);
  model:SetAnimationInterval(fb, fe);
  model:Reset();
  model:Play();
  return b3.SUCCESS;
end

return modelplay;