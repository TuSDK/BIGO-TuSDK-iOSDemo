local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local soundplay = b3.Class("SoundPlay", b3.Action)

function soundplay:ctor()
	b3.Action.ctor(self)	
	self.name = "SoundPlay"
end

function soundplay:tick(tick)
  local sound = tick.blackboard:get("soundscope");
  local loop = self.properties.loop == "true" and 0 or 1;
  sound:PlaySound(loop);
  return b3.SUCCESS;
end

return soundplay;