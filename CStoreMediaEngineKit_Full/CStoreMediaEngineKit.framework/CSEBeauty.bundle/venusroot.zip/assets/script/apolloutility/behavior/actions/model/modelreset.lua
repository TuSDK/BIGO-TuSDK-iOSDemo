local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local modelreset = b3.Class("ModelReset", b3.Action)

function modelreset:ctor(properties)
	b3.Action.ctor(self)	
	self.name = "ModelReset"
  self.frame = tonumber(properties.frame);
end

function modelreset:tick(tick)
  local model = tick.blackboard:get("modelscope");
  model:Reset(self.frame);
  return b3.SUCCESS;
end

return modelreset;