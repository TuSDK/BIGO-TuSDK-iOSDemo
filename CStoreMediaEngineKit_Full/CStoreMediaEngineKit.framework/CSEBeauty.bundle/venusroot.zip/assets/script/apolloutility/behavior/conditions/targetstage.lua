local b3 = require 'behavior3.b3';
require 'behavior3.core.Condition'


local targetstagecheck = b3.Class("TargetStageCheck", b3.Condition)

function targetstagecheck:ctor(properties, target)
  b3.Condition.ctor(self)
	self.name = "TargetStageCheck"
  self.stage = properties.stage;
end

function targetstagecheck:tick(tick)  
  local targetscope = tick.blackboard:get("targetscope");
  local stage = targetscope:GetStage();
  return stage == self.stage and b3.SUCCESS or b3.FAILURE;
end

return targetstagecheck;