local triggerdefined = require "videodecet.defined"
local videodecet = require "videodecet"
local b3 = require 'behavior3.b3';
require 'behavior3.core.Condition'
require "utility"

local targetface = b3.Class("TargetFace", b3.Condition)

function targetface:ctor()
  b3.Condition.ctor(self)
	self.name = "TargetFace"
end

function targetface:tick(tick)
  local face = tick.blackboard:get("facescope");
	return face and b3.SUCCESS or b3.FAILURE;
end

return targetface;