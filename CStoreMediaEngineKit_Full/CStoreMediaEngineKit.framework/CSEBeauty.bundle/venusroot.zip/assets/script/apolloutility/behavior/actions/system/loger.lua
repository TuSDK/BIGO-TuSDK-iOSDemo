local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local systemloger = b3.Class("SystemLoger", b3.Action)

function systemloger:ctor(properties)
	b3.Action.ctor(self)	
	self.name = "SystemLoger"
  self.content = properties.content;
end

function systemloger:tick(tick)
  LOG(self.content);
  return b3.SUCCESS;
end

return systemloger;