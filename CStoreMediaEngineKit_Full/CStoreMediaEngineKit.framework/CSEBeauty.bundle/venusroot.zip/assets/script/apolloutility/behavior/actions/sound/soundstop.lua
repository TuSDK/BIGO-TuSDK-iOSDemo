local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local soundstop = b3.Class("SoundStop", b3.Action)

function soundstop:ctor()
	b3.Action.ctor(self)	
	self.name = "SoundStop"
end

function soundstop:tick(tick)
  local sound = tick.blackboard:get("soundscope");
  sound:StopSound();
  return b3.SUCCESS;
end

return soundstop;