local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local particleshow = b3.Class("ParticleShow", b3.Action)

function particleshow:ctor()
	b3.Action.ctor(self)	
	self.name = "ParticleShow";
end

function particleshow:tick(tick)
  local particles = tick.blackboard:get("particlescope");
  for _,p in ipairs(particles) do
    p:SetShow(true);
  end
  return b3.SUCCESS;
end

return particleshow;