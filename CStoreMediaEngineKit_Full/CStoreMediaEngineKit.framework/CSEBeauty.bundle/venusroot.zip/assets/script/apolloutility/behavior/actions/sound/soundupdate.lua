local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local soundupdate = b3.Class("SoundUpdate", b3.Action)

function soundupdate:ctor()
	b3.Action.ctor(self)	
	self.name = "SoundStop"
end

function soundupdate:tick(tick)
  local sound = tick.blackboard:get("soundscope");
  local res = sound:isPlaying();
  return res == true and b3.RUNNING or b3.SUCCESS;
end

return soundupdate;