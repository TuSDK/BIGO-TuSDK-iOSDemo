local apollobehavior = {}

apollobehavior.ModelSetHide = require 'apolloutility.behavior.actions.model.modelhide';
apollobehavior.ModelPlay = require 'apolloutility.behavior.actions.model.modelplay';
apollobehavior.ModelReset = require 'apolloutility.behavior.actions.model.modelreset';
apollobehavior.ModelSetShow = require 'apolloutility.behavior.actions.model.modelshow';
apollobehavior.ModelStop = require 'apolloutility.behavior.actions.model.modelstop';
apollobehavior.ModelUpdate = require 'apolloutility.behavior.actions.model.modelupdate';

apollobehavior.SoundPlay = require 'apolloutility.behavior.actions.sound.soundplay';
apollobehavior.SoundStop = require 'apolloutility.behavior.actions.sound.soundstop';
apollobehavior.SoundUpdate = require 'apolloutility.behavior.actions.sound.soundupdate';

apollobehavior.ParticlePositionManipulate = require 'apolloutility.behavior.actions.particle.particlepositionmanipulate';
apollobehavior.ParticleUpdate = require 'apolloutility.behavior.actions.particle.particleupdate';
apollobehavior.ParticleHide = require 'apolloutility.behavior.actions.particle.particlehide';
apollobehavior.ParticleShow = require 'apolloutility.behavior.actions.particle.particleshow';
apollobehavior.ParticleParamMusic = require 'apolloutility.behavior.actions.particle.particleparammusic';
apollobehavior.ParticleParamReset = require 'apolloutility.behavior.actions.particle.particleparamreset';

apollobehavior.TimeRecover = require 'apolloutility.behavior.actions.time.timerecover';
apollobehavior.TimeSlowdown = require 'apolloutility.behavior.actions.time.timeslowdown';

apollobehavior.TargetSetStage = require 'apolloutility.behavior.actions.target.targetsetstage';

apollobehavior.SystemLoger = require 'apolloutility.behavior.actions.system.loger';

apollobehavior.TargetAction = require 'apolloutility.behavior.conditions.targetaction';
apollobehavior.TargetFace = require 'apolloutility.behavior.conditions.targetface';
apollobehavior.TargetStageCheck = require 'apolloutility.behavior.conditions.targetstage';

apollobehavior.isRunning = require 'apolloutility.behavior.decorators.isrunning';
apollobehavior.SoundScope = require 'apolloutility.behavior.decorators.soundscope';
apollobehavior.ModelScope = require 'apolloutility.behavior.decorators.modelscope';
apollobehavior.TargetScope = require 'apolloutility.behavior.decorators.targetscope';
apollobehavior.ParticleScope = require 'apolloutility.behavior.decorators.particlescope';

apollobehavior.VolumeAction = require 'apolloutility.behavior.conditions.volumeaction';
apollobehavior.VolumeActionCached = require 'apolloutility.behavior.conditions.volumeactioncached';
apollobehavior.ParticleReset = require 'apolloutility.behavior.actions.particle.particlereset';
apollobehavior.DisablePhysics = require 'apolloutility.behavior.actions.physics.physicsdisable';
apollobehavior.EnablePhysics = require 'apolloutility.behavior.actions.physics.physicsenable';
return apollobehavior;
