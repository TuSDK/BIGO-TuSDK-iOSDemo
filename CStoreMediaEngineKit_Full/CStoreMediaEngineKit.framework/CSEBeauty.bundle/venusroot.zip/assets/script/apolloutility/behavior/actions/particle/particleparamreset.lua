local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local particleparamreset = b3.Class("ParticleParamReset", b3.Action)

function particleparamreset:ctor(properties)
	b3.Action.ctor(self)	
	self.name = "ParticleParamReset";
  self.paramname = properties.paramname;
end

function particleparamreset:tick(tick)
  local particles = tick.blackboard:get("particlescope");
  for _,p in ipairs(particles) do
    p:SetParamMultipiler(self.paramname, 1);
  end
  return b3.SUCCESS;
end

return particleparamreset;