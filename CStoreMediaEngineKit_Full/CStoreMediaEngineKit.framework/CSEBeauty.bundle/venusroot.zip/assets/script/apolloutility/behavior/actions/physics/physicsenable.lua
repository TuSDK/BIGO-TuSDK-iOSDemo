local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local physicsenable = b3.Class("EnablePhysics", b3.Action)

function physicsenable:ctor()
	b3.Action.ctor(self)	
	self.name = "EnablePhysics"
end

function physicsenable:tick(tick)
    local physicsscope = tick.blackboard:get("physicsscope");
    if physicsscope~=nil then
       physicsscope:EnablePhysics();
    end
    return b3.SUCCESS;
end

return physicsenable;