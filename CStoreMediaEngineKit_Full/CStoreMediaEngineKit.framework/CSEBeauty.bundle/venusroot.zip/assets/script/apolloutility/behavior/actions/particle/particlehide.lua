local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local particlehide = b3.Class("ParticleHide", b3.Action)

function particlehide:ctor()
	b3.Action.ctor(self)	
	self.name = "ParticleHide";
end

function particlehide:tick(tick)
  local particles = tick.blackboard:get("particlescope");
  for _,p in ipairs(particles) do
    p:SetShow(false);
  end
  return b3.SUCCESS;
end

return particlehide;