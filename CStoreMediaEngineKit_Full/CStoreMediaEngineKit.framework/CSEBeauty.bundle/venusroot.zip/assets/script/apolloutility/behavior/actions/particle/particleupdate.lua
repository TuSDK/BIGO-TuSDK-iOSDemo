local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local particleupdate = b3.Class("ParticleUpdate", b3.Action)

function particleupdate:ctor(properties)
	b3.Action.ctor(self)	
	self.name = "ParticleUpdate"
end


function particleupdate:tick(tick)
  local timespan = tick.blackboard:get("timespan");
  local particles = tick.blackboard:get("particlescope");
  for _,p in ipairs(particles) do
    p:AsyncUpdate(timespan);
  end  
  return b3.RUNNING;--TODO:需要考虑发射器有生命周期的情况
end

return particleupdate;