local apolloengine = require "apolloengine"

local scenetimerender = {}
--对PBR材质中的贴图的slot进行初始化
function scenetimerender:Initialize()

 apolloengine.ShaderEntity.TEXTURE_NORMAL = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TEXTURE_NORMAL");

 apolloengine.ShaderEntity.TEXTURE_EMSSION = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TEXTURE_EMSSION");

end

return scenetimerender;
