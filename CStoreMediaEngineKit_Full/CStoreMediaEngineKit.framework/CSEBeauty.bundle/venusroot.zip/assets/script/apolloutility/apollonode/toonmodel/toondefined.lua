
--默认配置
local includeStr=[[
#include "comm:documents/material/shaders/surfacelighting.shader"
#include "comm:documents/material/shaders/directionlight.shader"
#include "comm:documents/material/shaders/ambientlight.shader"
#include "comm:documents/material/shaders/coordinate.shader"
#include "comm:documents/material/shaders/pointlight.shader"
#include "comm:documents/material/shaders/spotlight.shader"
#include "comm:documents/material/shaders/transform.shader"
#include "comm:documents/material/shaders/sampling.shader"
#include "comm:documents/material/shaders/outputs.shader"
#include "comm:documents/material/shaders/linerdepth.shader"
#include "comm:documents/material/shaders/packagedepth.shader"
]]


local meshNamePre =  "./data/button.mesh";
local defined = {
 matsrcType={["File"]=1,["String"]=2,},
 
 
 matuse={["./data/button.mesh"]="body",["./data/cheek.mesh"]="mat_cheek",["./data/hair_accce.mesh"]="body",["./data/hair_front.mesh"]="hair",["./data/hair_frontside.mesh"]="hair",["./data/hairband.mesh"]="body",["./data/leg.mesh"]="body",["./data/shirts.mesh"]="body",["./data/shirts_sode.mesh"]="body",
   ["./data/shirts_sode_back.mesh"]="body",["./data/skin.mesh"]="skin1",["./data/tail.mesh"]="hair",["./data/tail_bottom.mesh"]="hair",["./data/uwagi.mesh"]="body",
   ["./data/uwagi_bk.mesh"]="body",["./data/blw_def.mesh"]="eyeline",["./data/el_def.mesh"]="eyeline",["./data/blw_def.mesh"]="eyeline",["./data/eye_base_old.mesh"]="eyebase",["./data/eye_def.mesh"]="face",["./data/eye_l_old.mesh"]="eye_l1",["./data/eye_r_old.mesh"]="eye_r1",["./data/head_back.mesh"]="face",["./data/mth_def.mesh"]="face"},
  

hair_includeStr=includeStr..[[
#include "comm:documents/material/shaders/charahair.shader"

#OUTPUT TRUE
]],

skin_includeStr=includeStr..[[
#include "comm:documents/material/shaders/charaskin.shader"
]]
,
gammavalue = 1.0,

}
return defined;