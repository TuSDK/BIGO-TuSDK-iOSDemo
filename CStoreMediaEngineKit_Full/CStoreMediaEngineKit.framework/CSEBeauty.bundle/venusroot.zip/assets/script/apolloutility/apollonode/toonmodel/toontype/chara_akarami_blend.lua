

local toondefined = require "apolloutility.apollonode.toonmodel.toondefined"
local chara_akarami_blend=
{
   ["Properties"]= toondefined.skinPorperties
  -- {
   --   {"TEXTURE_DIFFUSE","2d",nil},
    --  {"TEXTURE_SKIN","2d",nil},
     -- {"TEXTURE_RIM","2d",nil},
   -- }
  ,
  ["Shader"]=
  { 
    ["IncludeStr"]=toondefined.skin_includeStr,
    ["RenderPaths"]=
    {
      {
        ["renderPathName"]="LIGHTING_DIRECTION_FORWARD_SINGLE",
        ["renderName"]="SimpleDirectionAkaramiBlend",
        ["trasnparentStr"]="OPAQUE".."+3",
        ["colorModeStr"]="COLOR_RGBA",
        ["alphaModeStr"]="{ ALPAH_BLEND, SRC_ALPHA, ONE_MINUS_SRC_ALPHA, ONE, ONE }",
        ["drawModeStr"]="{ CULL_FACE_BACK, DEPTH_MASK_OFF, DEPTH_TEST_ON, DEPTH_FUNCTION_LEQUAL }",
        ["stencilModeStr"]="{STENCIL_OFF}",
        ["vertexShaderStr"]=[[{"Base2DCoordinate","TransfromWorldPosition","DirectionLightVertex", "CharaSkinVertexDir","VertexOutput"}]],
        ["fragShaderStr"]=[[	{ "CharaSkinFragment","FragmentOutput"}]],
      },
    }
  }
}

return chara_akarami_blend;