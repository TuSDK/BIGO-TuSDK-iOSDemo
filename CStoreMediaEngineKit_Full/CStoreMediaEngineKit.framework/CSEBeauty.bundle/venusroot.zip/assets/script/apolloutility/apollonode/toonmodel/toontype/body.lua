local shaderhair = require "apolloutility.apollonode.toonmodel.toontype.chara_fuku_ds"
local toondefined = require "apolloutility.apollonode.toonmodel.toondefined"
local body=
{
   ["Properties"]=
   {
      {"TEXTURE_DIFFUSE","2d","comm:documents/tex/cartoon/body_01.tga"},
      {"TEXTURE_SKIN","2d","comm:documents/tex/cartoon/FO_CLOTH1.tga"},
      {"TEXTURE_RIM","2d","comm:documents/tex/cartoon/FO_RIM1.tga"},
      {"TEXTURE_SPECSAMPLER","2d","comm:documents/tex/cartoon/body_01_SPEC.tga"},
      --{"TEXTURE_ENVSAMPLER","2d","comm:documents/tex/cartoon/ENV2.tga"},
      --{"TEXTURE_NORMALSAMPLER","2d","comm:documents/tex/cartoon/body_01_NRM.tga"},
      {"Main_Color","color",{1.0,1.0,1.0,1.0}},
      {"Shadow_Color","color",{1.0,1.0,1.0,1.0}},
      {"Specular_Power","vec1",{20}},
      {"Gamma_Value","vec1",{toondefined.gammavalue}},
      {"FallofPower_Value","vec1",0.3},
      
    },
    Shader = shaderhair,
}


return body;