local toondefined = require "apolloutility.apollonode.toonmodel.toondefined"
local chara_fuku={
   ["Properties"]=toondefined.hairPorperties
   --{
    --  {"TEXTURE_DIFFUSE","2d",nil},
    --  {"TEXTURE_SKIN","2d",nil},
    --  {"TEXTURE_RIM","2d",nil},
    --  {"TEXTURE_SPECSAMPLER","2d",nil},
     -- {"TEXTURE_ENVSAMPLER","2d",nil},
     -- {"TEXTURE_NORMALSAMPLER","2d",nil}
    --}
  ,
  ["Shader"]=
  { 
    ["IncludeStr"]=toondefined.hair_includeStr,
    ["RenderPaths"]=
    {
      {
        ["renderPathName"]="LIGHTING_DIRECTION_FORWARD_SINGLE",
        ["renderName"]="SimpleDirectionFuKu",
        ["trasnparentStr"]="OPAQUE",
        ["colorModeStr"]="COLOR_RGBA",
        ["alphaModeStr"]="{ ALPAH_OFF, SRC_ALPHA, ONE_MINUS_SRC_ALPHA, ONE, ONE }",
        ["drawModeStr"]="{ CULL_FACE_BACK, DEPTH_MASK_ON, DEPTH_TEST_ON, DEPTH_FUNCTION_LEQUAL }",
        ["stencilModeStr"]="{STENCIL_OFF}",
        ["vertexShaderStr"]=[[{"Base2DCoordinate","TransfromWorldPosition","DirectionLightVertex", "CharaHairVertexDir","VertexOutput"}]],
        --["fragShaderStr"]=[[	{ "CharaHairFragment","FragmentOutput"}]],
        ["fragShaderStr"]=[[	{ "CharaHairSimpleFragment","FragmentOutput"}]],
      },
    }
  }
}


return chara_fuku;