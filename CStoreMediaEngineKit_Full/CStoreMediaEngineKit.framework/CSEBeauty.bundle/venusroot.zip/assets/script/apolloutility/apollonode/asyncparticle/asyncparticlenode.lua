local particleupdateservice = require "apolloutility.apollonode.asyncparticle.particleupdateservice"
local ParticleNode = require "apolloutility.apollonode.particlenode"
local defiend = require "apolloutility.defiend"
local mathfunction = require "mathfunction"
local apologine = require "apolloengine"
local venuscore = require "venuscore"
local venusjson = require "venusjson"


local AsyncParticleNode = ParticleNode:extend();


function AsyncParticleNode:CreateResource(config)
  AsyncParticleNode.super.CreateResource(self, config);
end

function AsyncParticleNode:AsyncUpdate(span)
  particleupdateservice:Scheduled(self.node, span);
end

return AsyncParticleNode;
