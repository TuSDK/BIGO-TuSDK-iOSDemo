local apolloengine = require "apolloengine"
local mathfunction = require "mathfunction"
local Object = require "classic"

--虚拟节点，不包含可渲染的组件
local VirtualNode = Object:extend();

function VirtualNode:new()
  self.node = apolloengine.Node();
  self.node:SetName("VirtualNode");
end

function  VirtualNode:SetName(name)
  self.node:SetName(name);
end

function  VirtualNode:CreateComponent(comtype)
  return self.node:CreateComponent(comtype);
end

function VirtualNode:AttachNode(input)
  self.node:AttachNode(input.node);
end

function VirtualNode:DetachNode(input)
  self.node:DetachNode(input.node);
end

return VirtualNode;