local toondefined = require "apolloutility.apollonode.toonmodel.toondefined"
local chara_eye_blend=
{
   ["Properties"]= toondefined.skinPorperties
  -- {
   --   {"TEXTURE_DIFFUSE","2d",nil},
   --   {"TEXTURE_SKIN","2d",nil},
   --   {"TEXTURE_RIM","2d",nil},
   -- }
  ,
  ["Shader"]=
  { 
    ["IncludeStr"]=toondefined.skin_includeStr,
    ["RenderPaths"]=
    {
      {
        ["renderPathName"]="LIGHTING_DIRECTION_FORWARD_SINGLE",
        ["renderName"]="SimpleDirectionEyeBlend",
        ["trasnparentStr"]="OPAQUE".."+1",
        ["colorModeStr"]="COLOR_RGBA",
        ["alphaModeStr"]="{ ALPAH_BLEND, SRC_ALPHA, ONE_MINUS_SRC_ALPHA, ONE, ONE }",
        ["drawModeStr"]="{ CULL_FACE_BACK, DEPTH_MASK_ON, DEPTH_TEST_ON, DEPTH_FUNCTION_LEQUAL }",
        ["stencilModeStr"]="{STENCIL_OFF}",
        ["vertexShaderStr"]=[[{"Base2DCoordinate","TransfromWorldPosition","DirectionLightVertex", "CharaSkinVertexDir","VertexOutput"}]],
        ["fragShaderStr"]=[[	{ "CharaSkinFragment","FragmentOutput"}]],
      },
    }
  }
}

return chara_eye_blend;