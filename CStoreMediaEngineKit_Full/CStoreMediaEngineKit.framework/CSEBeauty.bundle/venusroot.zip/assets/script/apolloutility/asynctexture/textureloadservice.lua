local ae = require "apolloengine"
require "utility"

local textureloadservice = {}

function textureloadservice:CreateTexture(agent, index, picoder, channelindex, path, premul, keep)
  local tex = ae.TextureEntity();
  if premul then
      tex:PushMetadata(ae.TextureFilePremultiplyAlphaMetadata(
      ae.TextureEntity.TU_STATIC,
      ae.TextureEntity.PF_AUTO,
      1, false,
      ae.TextureEntity.TW_CLAMP_TO_BORDER,
      ae.TextureEntity.TW_CLAMP_TO_BORDER,
      ae.TextureEntity.TF_LINEAR,
      ae.TextureEntity.TF_LINEAR,
      path));
  else
    tex:PushMetadata(ae.TextureFileMetadata(
      ae.TextureEntity.TU_STATIC,
      ae.TextureEntity.PF_AUTO,
      1, false,
      ae.TextureEntity.TW_CLAMP_TO_BORDER,
      ae.TextureEntity.TW_CLAMP_TO_BORDER,
      ae.TextureEntity.TF_LINEAR,
      ae.TextureEntity.TF_LINEAR,
      path));
  end
  if keep then
    tex:SetKeepSource(keep);
  end  
  tex:CreateResource();
  agent:CallbackFunction(index, picoder, channelindex, tex);
  tex:Discard();--在序列化传递之后，需要将本地副本也clear掉DiscardDiscard
end

function textureloadservice:Wait()
  return true;
end

function textureloadservice:Clear()
  collectgarbage();
  return true;
end

return textureloadservice;