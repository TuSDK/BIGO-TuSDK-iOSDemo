local vc = require "venuscore";

local textureloader = {}

if _PLATFORM_WINDOWS then
  collectgarbage("setpause",200);
  collectgarbage("setstepmul",3000);
end

function textureloader:Initialize()
  self.service = vc.IServicesSystem:Create("apolloutility.asynctexture.textureloadservice");
end

function textureloader:CreateTexture(agent, index, picoder, channelindex, path, premul, keep)
  self.service:CreateTexture(agent, index, picoder, channelindex, path, premul or false, keep or false)
end

function textureloader:Wait()
  return self.service:Wait()
end

function textureloader:Clear()
  return self.service:Clear()
end

return textureloader;
