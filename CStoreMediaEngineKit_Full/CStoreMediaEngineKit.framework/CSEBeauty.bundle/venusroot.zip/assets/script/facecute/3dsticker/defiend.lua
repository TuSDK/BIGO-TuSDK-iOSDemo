
--默认配置
local defined = {
  sequence_animation_keep_max_count = 5,--最大只有n个纹理的序列帧动画不释放资源
  queue_camera_count = 30,
  blit_material_path = "docs:facecute/commaterial/imageblit.material",
  model_simple_material_path = "docs:facecute/commaterial/nl_simple.material",
  model_dual_material_path = "docs:facecute/commaterial/nl_skeleton%dbdual%s.material",
  model_matrix_material_path = "docs:facecute/commaterial/nl_skeleton%dbmatrix%s.material",
  model_pbr_dual_material_path = "comm:documents/material/pbr_skeleton%dbdual%s.material",
  model_pbr_matrix_material_path = "comm:documents/material/pbr_skeleton%dbmatrix%s.material",
	model_pbr_material_path = "comm:documents/material/pbr.material",
  model_reflection_path = "docs:facecute/commaterial/nl_reflection.material",
  diff_specular_bump_env_opaque_lighting = "comm:documents/material/nl_reflectionadv.material";
  
  --图片压缩
  compress_root_key = "compress_root",
  ext_key = "compress_ext",
  split_key = "compress_split",
  rgb_fix_key = "compress_rgb_fix",
  alpha_fix_key = "compress_alpha_fix",
  rgb_fix = "_rgb",
  alpha_fix = "_alpha",
  ktx_dir = "/android/",
  ktx_ext = ".ktx",
  pvrtc_dir = "/ios/",
  pvrtc_ext = ".pvr",
  jpg_dir = "/windows/",
  jpg_ext = ".jpg",
  png_dir = "/lowresolution/",
  png_ext = ".png",
  image_size_key = "original_image_size",
  
  --skybox
  skybox_left = "comm:documents/skybox/left.jpg",
  skybox_right= "comm:documents/skybox/right.jpg",
  skybox_top = "comm:documents/skybox/top.jpg",
  skybox_bottom = "comm:documents/skybox/bottom.jpg",
  skybox_front = "comm:documents/skybox/front.jpg",
  skybox_back = "comm:documents/skybox/back.jpg",
  
  --pbr材质
  model_pbr_material_path = "docs:facecute/commaterial/pbr.material",
}
return defined;
