local apollonode = require "apolloutility.apollonode"
local headtarget =  require "facecute.headtarget";

local immortal = headtarget:extend();

function immortal:new(maincamera)
  self.assets = {};--保存全部的资源
  self.sounds = {};--声音要全部停止
  self.maincamera = maincamera;
  self.head = apollonode.TransNode();
end

--设置是否显示
function immortal:SetShow(isshow)
  for _, node in ipairs(self.assets) do
    node:SetShow(isshow);
  end  
end


--更新
function immortal:Update(timespan, face, position, rotation, action)
  for _, node in ipairs(self.assets) do
    node:Update(timespan, face, position, rotation, action);
  end  
end


return immortal;

