local apolloengine = require "apolloengine"
local mathfunction = require "mathfunction"
local facecovermakeup = require "facecute.facechange.facecovermakeup"
local facechange3 = require "facecute.facechange.facechange3"
--管理多个facechange
local facechangemakeup = facechange3:extend();

function facechangemakeup:new(maincamera, makeuptype, isallpoint)
  facechange3.super.new(self, maincamera);
  if isallpoint then
    self.facecoverpri = facecovermakeup(self.maincamera);
  end
  self.type = makeuptype;
end

function facechangemakeup:SetMakeuptype(makeuptype)
  self.type = makeuptype;
end

function facechangemakeup:GetMakeuptype()
  return self.type;
end

return facechangemakeup;