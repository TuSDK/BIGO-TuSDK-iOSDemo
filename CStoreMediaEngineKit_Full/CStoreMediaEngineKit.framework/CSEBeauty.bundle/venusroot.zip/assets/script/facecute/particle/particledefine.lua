
local useroffset =5;
local particledefine=
{
  zposOffset=-2000,
  
  	emitterAffector=
		{
			EA_PARTICLE_DENSITY = 0,---喷射器每秒喷射个数
			EA_PARTICLE_LIFE=1,--粒子存活时间
			EA_PARTICLE_SPEED=2,--粒子速度
			EA_PARTICLE_ACCELERATION=3,--粒子加速度
			EA_PARTICLE_SIZE=4,--粒子尺寸
			EA_PARTICLE_SIZE_CURVATURE=5,--粒子尺寸曲率
			EA_PARTICLE_COLOR=6,--颜色变化
			EA_PARTICLE_COLOR_CURVATURE=7,--颜色变化曲率
			EA_PARTICLE_SPIN=8,--自旋
			EA_PARTICLE_POSITION_NOISE=9,--位置噪点
			EA_PARTICLE_AXIS_NOISE=10,--发射轴噪点
			EA_PARTICLE_STRETCH=11,  --速度方向缩放
			EA_PARTICLE_ROTATION=12,    --绕轴旋转
			EA_PARTICLE_DISTRUBANCE=13,  --顶点扰动幅度
			EA_PARTICLE_MAX_SIZE=14, --粒子最大数目
      
      
			EA_PARTICLE_ANIMATION_TILES=15,  --15: 
			EA_PARTICLE_ANIMATION_MODE=16,    --16
			EA_PARTICLE_ANIMATION_ROW=17,     --17
			EA_PARTICLE_ANIMATION_CYCLES=18,  --18
			EA_PARTICLE_ANIMATION_CONSTANT_FRAME=19,   --19
			EA_PARTICLE_ANIMATION_START_FRAME=20,   --20
			EA_PARTICLE_ANIMATION=21,
      EA_PARTICLE_SPHERE=22,
			EA_PARTICLE_CONE=23,
			EA_PARTICLE_BOX=24,
			EA_PARTICLE_CIRCLE=25,
			EA_PARTICLE_HEMISPHERE=26,



			EA_PARTICLE_USER_0=22+useroffset,
			EA_PARTICLE_USER_1=23+useroffset,
			EA_PARTICLE_USER_2=24+useroffset,
			EA_PARTICLE_USER_3=25+useroffset,
			EA_PARTICLE_USER_4=26+useroffset,
			EA_PARTICLE_USER_5=27+useroffset,
			EA_PARTICLE_USER_6=28+useroffset,
			EA_PARTICLE_USER_7=29+useroffset,
			EA_COUNT=30,
		};
    
    
    emitterDataType=
		{
			DST_VECTOR1 = 0,
			DST_VECTOR2=1,
			DST_VECTOR3=2,
			DST_VECTOR4=3,
			DST_MATRIX22=4,
			DST_MATRIX33=5,
			DST_MATRIX44=6,
		},
    
    
    particleParameter=
		{
			PARAM_INITIAL_LINEAR_VELOCITY=0, --初始速度
			PARAM_ANGULAR_VELOCITY=1,        --角速度
			PARAM_LINEAR_ACCEL=2,            --线加速度
			PARAM_RADIAL_ACCEL=3,            --径向加速度
			PARAM_TANGENTIAL_ACCEL=4,        --切向加速度
			PARAM_DAMPING=5,                 --阻尼
			PARAM_ANGLE=6,                   --角度
			PARAM_SCALE=7,                   --缩放
			PARAM_HUE_VARIATION=8,           --色度
			PARAM_SATURATION_VARIATION=9,    --饱和度变化
			PARAM_BRIGHTNESS_VARIATION=10,         --亮度变化
			PARAM_ALPHA_VARIATION=11,         --alpha变化
			PARAM_COLOR_VARIATION=12,         --RGB颜色变化
			PARAM_STRETCH=13,                 --速度方向stretch
			PARAM_ROT_X=14,                   --绕世界轴旋转
			PARAM_ROT_Y=15,
			PARAM_ROT_Z=16,
			PARAM_EXTERNAL_FORCE_X=17,                  --外力
			PARAM_EXTERNAL_FORCE_Y=18,
			PARAM_EXTERNAL_FORCE_Z=19,
			PARAM_VERTEX_DISTURBANCE_AMPLITUDE=20,  --顶点扰动幅度
			PARAM_ANIMATION_FRAME=21,         --粒子序列帧动画帧随时间的变化
			PARAM_MAX=22,
		},
    
    emitterSimuspace=
    {
      ["world"]=1,
      ["local"]=2,
    },
   randomBegin=0,
   randomEnd=1024,
   emitterShape={["cone"]=1,["sphere"]=2,["box"]=3,["circle"]=4,["sphereshell"]=5},
   rendermode={["billboard"]="BillboardTransform"},
   arcToDegree = 180/3.1415926,
   valueTypeStr={ ["constant"]="constant",
     ["color"]="color",
     ["twocolors"]="twocolors",
     ["twoconstants"]="twoconstants",
     ["curve"]="curve",
     ["gradient"]="gradient"},
   valueType={
     ["constant"]=1,
     ["color"]=2,
     ["twocolors"]=3,
     ["twoconstants"]=4,
     ["curve"]=5,
     ["gradient"]=6
   },
   
   strenchBillBoardName="strenchedbillboard",
   strenchBillBoardCof=0.1,
}
return particledefine;