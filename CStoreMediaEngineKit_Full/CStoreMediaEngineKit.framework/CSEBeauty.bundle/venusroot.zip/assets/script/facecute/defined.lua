
--默认配置
local defined = {

  positionType = {
    ForeGround           = 0,
    PosSizeDepthRotation = 1,
    PosSizeRotation      = 2,
    PosSize              = 4,
    Hand                 = 262144,
    Background           = 65536
  },
  positionTypeHand = {
    OK             = 2^9,
    Scissor        = 2^10,
    ThumbUp        = 2^11,
    Palm           = 2^12,
    Pistol         = 2^13,
    Love           = 2^14,
    Holdup         = 2^15,
    Congratulate   = 2^17,
    FingerHeart    = 2^18,
    IndexFinger    = 2^20,
    Fist          = 2^21,
    Six           = 2^22,
    Bless         = 2^23,
  },

  background_segment_flag = 2^16,
  max_head_target_count = 3,
  bezier_material_path = "docs:facecute/material/bezier.material",
  transfer_material_path = "docs:facecute/material/transfer.material",
  --bezier_material_path = "comm:documents/material/lightingonly.material",
  --transfer_material_path = "comm:documents/material/lightingonly.material",
  cricle_point_count = 256,
  headtarget_human_head_material = "comm:documents/material/depthonly.material",
  --headtarget_human_head_material = "comm:documents/material/lightingonly.material",
  --headtarget_human_head_mesh = "comm:documents/model/head",
  headtarget_human_head_mesh = "docs:/model/head",
  facechange_material_path = "docs:facecute/material/facechange.material",
  --facesticker2d_material_path = "docs:facecute/material/sticker2drect.material",
   facesticker2d_material_path = "docs:facecute/material/sticker2dmat.material",
  }

return defined;
