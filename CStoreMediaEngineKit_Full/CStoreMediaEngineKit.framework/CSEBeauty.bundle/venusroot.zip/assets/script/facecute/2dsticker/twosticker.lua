local apollonode = require "apolloutility.apollonode"
local apolloengine = require "apolloengine"
local mathfunction = require "mathfunction"
local Object = require "classic"


--管理一组3d模型
local threesticker = Object:extend();

function threesticker:new()
  self.threesticker = {}
end

--传入数据表，解析数据
function threesticker:ParseConfig(config)
end

function threesticker:SetShow(isshow)
  for _, mesh in ipairs(self.threesticker) do
    mesh:SetShow(isshow);
  end  
end

function threesticker:SetRootNode(node)
  for _, mesh in ipairs(self.threesticker) do
    mesh:AttachNode(def);
  end  
end


return threesticker;