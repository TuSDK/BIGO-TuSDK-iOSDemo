
local bezier = require "facecute.deformation.bezier"
--贝塞尔变形器
local bezier3 = bezier:extend();
local defordefined = require "facecute.deformation.defordefined"
local renderqueue = require "apolloutility.renderqueue"
function bezier3:Play(delay ,loop,lastingFrame,fadingFrame,donecallback)
  self:SetVisible(true);
  --self:Render();
  self:setState("playing")
end


function bezier3:Stop()
  self:SetVisible(false);
  --self:Render();
  self:setState("invisible")
end

function bezier3:Pause()
  self:setState("paused")
end

function bezier3:PauseInFirstFrame()
  self:setState("first_frame")
end

function bezier3:PauseInLastFrame()
  self:setState("last_frame")
end

function bezier3:Hide()
  self:setState("invisible")
  self:Stop();
end

function bezier3:TestTrigger()
  if self.triggerFlag then
    self.triggerFlag = false
    return self.cur_state3
  end
  return nil
end

function bezier3:setState(state)
  if self.cur_state3 ~= state then
    self.triggerFlag = true
    self.cur_state3 = state
  end
end

function bezier3:GetMaterialPath()
  return defordefined.bezier_material_path3;
end

function bezier3:new(maincamera)
  bezier3.super.new(self,maincamera);
  self.cur_state3 = "invisible";
  self.triggerFlag = false;
end

function bezier3:GetRenderOrder()
  return self.addIndex/10000+renderqueue:GetMaxFaceOrder();
end

function bezier3:Update(timespan, face, position, rotation, action)
  self.timespan = timespan;
  self.frames = self.frames+1;
  self.action = action;
  self.face = face;
  self.curFrame= self.curFrame+1;
  self:ResetEvent();
  self:Render();
  --cutebehavior:tick(self);
end

return bezier3;
