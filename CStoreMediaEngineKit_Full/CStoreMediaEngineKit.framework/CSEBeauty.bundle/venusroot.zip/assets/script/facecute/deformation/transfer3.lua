
local transfer = require "facecute.deformation.transfer"
local defordefined = require "facecute.deformation.defordefined"
local renderqueue = require "apolloutility.renderqueue"
local transfer3 = transfer:extend()

function transfer3:Update(timespan, face, position, rotation, action)
   self.timespan = timespan;
   self.frames = self.frames+1;
   self.action = action;
   self.curFrame= self.curFrame+1;
   self:ResetEvent();
   self:Render();
   --cutebehavior:tick(self);
end


function transfer3:Play(delay ,loop,lastingFrame,fadingFrame,donecallback )
  self:SetVisible(true);
  --self:Render();
  self:setState("playing")
end

function transfer3:Stop()
  self:SetVisible(false);
  --self:Render();
  self:setState("invisible")
end


function transfer3:Pause()
  self:setState("paused")
end

function transfer3:PauseInFirstFrame()
  self:setState("first_frame")
end

function transfer3:PauseInLastFrame()
  self:setState("last_frame")
end

function transfer3:Hide()
  self:setState("invisible")
  self:Stop();
end

function transfer3:TestTrigger()
    if self.triggerFlag then
        self.triggerFlag = false
        return self.cur_state3
    end
    return nil
end

function transfer3:setState(state)
    if self.cur_state3 ~= state then
        self.triggerFlag = true
        self.cur_state3 = state
    end
end

function transfer3:new(maincamera)
    transfer3.super.new(self, maincamera);
    self.cur_state3 = "invisible";
    self.triggerFlag = false;
end


function transfer3:GetRenderOrder()
  return self.addIndex/10000+renderqueue:GetMaxFaceOrder();
end

function transfer3:GetMaterialPath()
  return defordefined.transfer_material_path3;
end


return transfer3;
