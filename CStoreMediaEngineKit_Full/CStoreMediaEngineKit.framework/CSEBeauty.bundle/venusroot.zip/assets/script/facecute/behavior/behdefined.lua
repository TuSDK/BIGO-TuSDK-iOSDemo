local behdefined={
behaviorPath={"docs:facecute/behaviortree/behaviortree.json",},  
stateType ={NULL=0,PausedInFirst=1,Playing=2,Paused=3,PausedInLast=4,Invisible=5},
eventType ={NULL=0,Begin=1,Play=2,Pause = 3,End = 4,Hide = 5},
triggerType={NULL=0,Blink=2,OpenMouth=2^2,ShakeHead=2^3,NodeHead=2^4,BrowJump=2^5,OK=2^9, Scissor=2^10,ThumbUp=2^11,
  Palm=2^12,Pistol=2^13,Love=2^14,Holdup=2^15, Congratulate=2^17,FingerHeart=2^18,IndexFinger=2^20},
targetType={NULL=0,Sticker2D=1,Facechange=2,Deformation=3,Sticker3D=4,Music=5},
}

return behdefined;