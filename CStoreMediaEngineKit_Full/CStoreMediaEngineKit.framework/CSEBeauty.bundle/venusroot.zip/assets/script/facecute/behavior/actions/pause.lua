local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'
local behdefined = require "facecute.behavior.behdefined"
local pause= b3.Class("Pause", b3.Action)

function pause:ctor()
	b3.Action.ctor(self)	
	self.name = "Pause";
end

function pause:tick(tick)
  
    local rect = tick.target;
    if(rect.stateType==behdefined.stateType.PausedInFirst)
    then
       rect:PauseInFirstFrame();
    elseif(rect.stateType==behdefined.stateType.PausedInLast)
    then
       rect:PauseInLastFrame();
    elseif (rect.stateType==behdefined.stateType.Paused)
    then 
       rect:Pause();
    else
       return b3.FAILURE;
    end
    
    if(rect.PasueMark)
    then
       rect:AddEvent( behdefined.eventType.Pause);
       rect.PasueMark = false;
    end   
    return b3.SUCCESS;
    
end


return pause;