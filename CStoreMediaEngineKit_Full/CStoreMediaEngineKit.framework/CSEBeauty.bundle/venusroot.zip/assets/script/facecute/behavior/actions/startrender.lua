local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'
local behdefined = require "facecute.behavior.behdefined"

local startrender= b3.Class("StartRender", b3.Action)

function startrender:ctor()
	b3.Action.ctor(self)	
	self.name = "StartRender";
end

function startrender:tick(tick)
  local rect = tick.target;
 if( rect.stateChange==false or (rect.triggerStop==false and (rect.curLoop>0 or (rect.triggerLoop==0 or rect.triggerLoop==nil))))
  then
    return b3.SUCCESS;
  end
  rect.stateChange = false;
 -- LOG("startrender")
 if(rect.stateType==behdefined.stateType.Playing) 
  then
     rect.PlayMark = true;
     rect:ResetLoopCount();
     if(rect.texturereader~=nil)
     then
        rect.texturereader:SetAccTime(0);
        rect.texturereader:Preloading();
     end
  elseif(rect.stateType==behdefined.stateType.PausedInFirst or rect.stateType==behdefined.stateType.PausedInLast or
     rect.stateType==behdefined.stateType.Paused)
  then 
     rect.PasueMark = true;
     rect:ResetLoopFrameCount();
  elseif(rect.stateType==behdefined.stateType.Invisible) 
  then
     rect.InvisibleMark = true;
  end
    return b3.SUCCESS;
end
return startrender;