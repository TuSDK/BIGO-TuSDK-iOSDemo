local b3 = require 'behavior3.b3';
require 'behavior3.core.Decorator'
local behdefined = require "facecute.behavior.behdefined"
local loop = b3.Class("Loop", b3.Decorator)
--b3.Loop = loop;

function loop:ctor()
  b3.Decorator.ctor(self)
	self.name = "Loop"
end

function loop:tick(tick)
	
  local rect = tick.target; 
  if(rect.stateType~=behdefined.stateType.Playing)
  then
    return b3.FAILURE;
  end
  
  if not self.child then
		return b3.ERROR
	end

  if(rect.triggerLoop==0 or rect.triggerLoop==nil)
  then
     return self.child:_execute(tick);--unlimited loop
  else
    
   if(rect.texturereader~=nil)
   then
        local lc= rect.triggerLoop-rect.texturereader:GetNextLoopCount(rect.timespan);
        if(lc<=0)
        then
           rect:SetVisible(false);
           rect.curLoop = 0;
           rect.curTime = 0;
           rect.stateType=behdefined.stateType.NULL;
           return b3.FAILURE;
        end
    end
    
    rect.curLoop = rect.triggerLoop-rect:GetLoopCount();
    if(rect.curLoop<=0)
    then
       rect.stateType=behdefined.stateType.NULL;
       rect:SetVisible(false);
       rect.curLoop = 0;
       rect.curTime = 0;
       return b3.FAILURE;
    else
        return  self.child:_execute(tick);
    end
    
  end
  return b3.SUCCESS;
end

return loop;