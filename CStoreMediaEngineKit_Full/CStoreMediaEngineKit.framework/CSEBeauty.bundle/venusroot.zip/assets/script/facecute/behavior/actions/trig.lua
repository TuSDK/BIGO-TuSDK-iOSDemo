local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'
local behdefined = require "facecute.behavior.behdefined"
local trig= b3.Class("Trig", b3.Action)
local triggerfilter = require "facecute.behavior.triggerfilter"
function trig:ctor()
	b3.Action.ctor(self)	
	self.name = "Trig";
end

function trig:tick(tick)
  local rect = tick.target;
  --[[if(rect.version>=3)
  then
   return true;
  end]]--
  if(triggerfilter:onTrigger(rect))
  then
     if(rect.stateType==behdefined.stateType.NULL)
     then
       if(rect.texturereader~=nil)
       then
          rect.texturereader:SetAccTime(0);
          rect.texturereader:Preloading();
       end
       rect:SetVisible(false);
       return b3.FAILURE;
     end
     return b3.SUCCESS;
  else
    return b3.FAILURE;
  end
end
return trig;