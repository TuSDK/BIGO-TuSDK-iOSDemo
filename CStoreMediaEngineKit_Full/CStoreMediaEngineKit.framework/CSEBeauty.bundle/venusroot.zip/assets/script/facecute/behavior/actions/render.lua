local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'
local behdefined = require "facecute.behavior.behdefined"
local render= b3.Class("Render", b3.Action)

function render:ctor()
	b3.Action.ctor(self)	
	self.name = "Render";
end

function render:tick(tick)
  local rect = tick.target;
  rect:Play();
      -- return b3.RUNNING;
   if(rect.PlayMark)
   then
     rect:AddEvent( behdefined.eventType.Play);
     rect.PlayMark = false;
   end
   return b3.SUCCESS;
end

return render;