local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'
local behdefined = require "facecute.behavior.behdefined"

local delay= b3.Class("Delay", b3.Action)

function delay:ctor()
	b3.Action.ctor(self)	
	self.name = "Delay";
  --self.curTime = 0 ;
end

function delay:tick(tick)
  
  local rect = tick.target;
  if(rect.curTime==0) 
  then
    rect:AddEvent( behdefined.eventType.Begin);
  end 

  if(rect.triggerDelay==nil)
  then
     return b3.SUCCESS;
  end
   
  rect.curTime = rect.curTime+1;
  if( rect.curTime>rect.triggerDelay)
  then
    return b3.SUCCESS;
  else
  return b3.FAILURE;
  end


end

return delay;