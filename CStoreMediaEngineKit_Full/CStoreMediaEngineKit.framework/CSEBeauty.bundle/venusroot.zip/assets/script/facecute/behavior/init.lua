local gab = {}
gab.Delay = require 'facecute.behavior.actions.delay'
gab.Render = require 'facecute.behavior.actions.render'
gab.StartRender = require 'facecute.behavior.actions.startrender'
gab.Pause = require "facecute.behavior.actions.pause"
gab.Trig = require 'facecute.behavior.actions.trig'
gab.Invisible = require 'facecute.behavior.actions.invisible'
gab.Loop = require 'facecute.behavior.decorators.loop'
gab.Loopframe = require 'facecute.behavior.decorators.loopframe'
return gab;
