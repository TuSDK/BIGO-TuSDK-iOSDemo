local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'
local behdefined = require "facecute.behavior.behdefined"
local invisible= b3.Class("Invisible", b3.Action)

function invisible:ctor()
	b3.Action.ctor(self)	
	self.name = "Invisible";
end

function invisible:tick(tick)
   local rect = tick.target;
   if(rect.stateType~=behdefined.stateType.Invisible)
   then
     return b3.FAILURE;
   end
   rect:Hide();
   rect:AddEvent( behdefined.eventType.Hide);
   return b3.SUCCESS;
end

return invisible;