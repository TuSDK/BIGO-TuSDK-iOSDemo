local b3 = require 'behavior3.b3';
require 'behavior3.core.Decorator'
local behdefined = require "facecute.behavior.behdefined"
local loopframe = b3.Class("Loopframe", b3.Decorator)
--b3.Loop = loop;

function loopframe:ctor()
  b3.Decorator.ctor(self)
	self.name = "Loopframe"
end

function loopframe:tick(tick)
	
  local rect = tick.target;  
  if(rect.stateType~=behdefined.stateType.PausedInFirst and rect.stateType~=behdefined.stateType.PausedInLast
    and rect.stateType~=behdefined.stateType.Paused)
  then
    return b3.FAILURE;
  end
  
  if not self.child then
		return b3.ERROR
	end
 
  if(rect.triggerLoopFrame==0 or rect.triggerLoopFrame==nil)
  then
     return self.child:_execute(tick);--unlimited loop
  else
    rect.curLoopFrame = rect.triggerLoopFrame-rect:GetLoopFrameCount();
    if(rect.curLoopFrame<=0)
      then
         rect.curLoopFrame = 0;
         rect.stateType=behdefined.stateType.NULL;
         rect:SetVisible(false);
         return b3.FAILURE;
       else
         return self.child:_execute(tick);
    end
  end
  return b3.SUCCESS;
end

return loopframe;