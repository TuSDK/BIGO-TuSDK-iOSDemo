
--默认配置
local haircolordefined = 
{
  boundingbox_material = "docs:facecute/material/haircolor_boundingbox.material",
  colorbox_material = "comm:documents/material/nl_simple.material",
  changecolor_material = "docs:facecute/material/haircolor_changecolor.material",
  changecolor_material_2 = "docs:facecute/material/haircolor_changecolor_v2.material",
  quadclear_material = "docs:facecute/material/haircolor_clear.material",
  laplace_sharpen_material = "docs:facecute/material/haircolor_sharpen.material",
  hairdenoise_material = "docs:facecute/material/denoise.material",
  historical_frame_material = "docs:facecute/material/hairseg.material",
  hair_denoise_sequence = -10002,
  hair_boundingbox_sequence = -10001,
  hair_changecolor_sequence = -10000
}

return haircolordefined;
