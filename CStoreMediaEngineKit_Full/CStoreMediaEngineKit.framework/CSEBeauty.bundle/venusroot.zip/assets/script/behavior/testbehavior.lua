local venuscore = require "venuscore"
local mathfunction = require "mathfunction"


local TestBehavior = venuscore.VenusBehavior:extend("TestBehavior");

TestBehavior:MemberRegister("offset");
TestBehavior:MemberRegister("isactive");
TestBehavior:MemberRegister("path");
TestBehavior:MemberRegister("rotation");
TestBehavior:MemberRegister("float");
TestBehavior:MemberRegister("uv");
TestBehavior:MemberRegister("pos");
TestBehavior:MemberRegister("enum", 
  {
    types = venuscore.Types.Combo,
    datas = 
      {
        Left = 1,
        Right = 2,
      }
  });



function TestBehavior:new()
  self.size = 1.0;
  self.isactive = true;
  self.offset = mathfunction.vector3();
  self.float = mathfunction.vector1();
  self.uv = mathfunction.vector2();
  self.pos = mathfunction.vector4();
  self.path = "docs:tt.jpg"
  self.rotation = mathfunction.Quaternion();
  self.test = {}
  self.test.rotation = mathfunction.Quaternion();
  self.test.path = "docs:tt.jpg"
  self.enum = 1;
end

function TestBehavior:Update(def)
end

return TestBehavior;