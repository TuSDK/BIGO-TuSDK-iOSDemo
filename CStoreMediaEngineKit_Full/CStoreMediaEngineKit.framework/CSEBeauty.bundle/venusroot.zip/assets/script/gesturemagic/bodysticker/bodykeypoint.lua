local Object = require "classic"
local ae = require "apolloengine"
local am = require "mathfunction"
local fbm =require "fakebodymagic"

local BodyKeypoint = Object:extend();


function BodyKeypoint:new()  
  self.keypointgenerator = fbm.BodyMagicKeyPoint();--创建关键点识别类;
end

function BodyKeypoint:GetKeypoint()  
  local keypoints = {}
  local orikeypoints = self.keypointgenerator:GetKeyPoints();--将表转为vector2
  for name, point in pairs(orikeypoints) do
    keypoints[name] = am.vector2(point[1], point[2]);
  end  
  return keypoints;
end


return BodyKeypoint;