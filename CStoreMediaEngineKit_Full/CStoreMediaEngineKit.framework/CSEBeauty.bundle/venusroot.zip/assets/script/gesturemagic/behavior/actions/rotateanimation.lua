local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local rotateanimation = b3.Class("RotateAnimation", b3.Action)

function rotateanimation:ctor()
	b3.Action.ctor(self)
	self.name = "RotateAnimation"
end

function rotateanimation:tick(tick)
  local gestureanimation = tick.target;
  local radian = self.properties.Radian;
  gestureanimation.sequenceAnimation:RotateAnimation(radian);
	return b3.SUCCESS;
end

return rotateanimation;
