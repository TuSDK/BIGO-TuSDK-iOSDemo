local gab = {}

gab.UpdateAnimation = require 'gesturemagic.behavior.actions.updateanimation'
gab.RotateAnimation = require 'gesturemagic.behavior.actions.rotateanimation'
gab.PlayAnimation = require 'gesturemagic.behavior.actions.playanimation'

gab.isAction = require 'gesturemagic.behavior.conditions.isaction'


return gab;
