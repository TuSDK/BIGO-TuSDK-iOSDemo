local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local playanimation = b3.Class("PlayAnimation", b3.Action)

function playanimation:ctor()
	b3.Action.ctor(self)	
	self.name = "PlayAnimation"
end

function playanimation:tick(tick)
  local gestureanimation = tick.target;
  local picPath = self.properties.Path;
  local rgbTextureName = self.properties.rgbtexture;
  local alphaTextureName = self.properties.alphatexture;
  local fps = self.properties.fps;
  local isloop = true;
  if self.properties.isloop == "false" or self.properties.isloop == nil then
    isloop = false;
  end
  if self.play == nil or self.play == false then
      self.play = gestureanimation.sequenceAnimation:Play(picPath, rgbTextureName,alphaTextureName,fps, isloop, 0, false);
  end
  if self.play then
    return b3.SUCCESS;
  else
    return b3.FAILURE;
  end
end

return playanimation;