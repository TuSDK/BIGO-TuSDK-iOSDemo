local b3 = require 'behavior3.b3';
require 'behavior3.core.Condition'

local isaction = b3.Class("isAction", b3.Condition)

function isaction:ctor()
	--b3.Inverter.ctor(self)
  b3.Condition.ctor(self)
	self.name = "isAction"
end

function isaction:tick(tick)
  local gestureaction = tick.blackboard:get("gestureaction");
	return gestureaction:isAction(self.properties.Action) and b3.SUCCESS or b3.FAILURE;
end

return isaction;
