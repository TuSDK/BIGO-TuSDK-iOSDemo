local b3 = require 'behavior3.b3';
require 'behavior3.core.Action'

local updateanimation = b3.Class("UpdateAnimation", b3.Action)

function updateanimation:ctor()
	b3.Action.ctor(self)	
	self.name = "UpdateAnimation"
end

function updateanimation:tick(tick)
  local gestureanimation = tick.target;
  local deltaT = gestureanimation.def;
  local isPlaying = gestureanimation.sequenceAnimation:Update(deltaT);
  if (isPlaying) then
    return b3.RUNNING;
  else
    return b3.FAILURE
  end
end

return updateanimation;