local sticker2ddefine = require "facecute.facesticker2d.sticker2ddefine"
local facedefinde = require "facecute.facechange.facedefined"
local apollonode = require "apolloutility.apollonode"
local apolloengine = require "apolloengine"
local defined = require "facecute.defined"

local preloading = {}

function preloading:PreloadingMaterail()
  apolloengine.ShaderEntity.UNIFORM_MATMVP =apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "UNIFORM_MATMVP");
    
  apolloengine.ShaderEntity.UNIFORM_CUSTOMER_DEPTH =apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "UNIFORM_CUSTOMER_DEPTH");
    
  apolloengine.ShaderEntity.TEXTURE_DIFFUSE_RGB =apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_DIFFUSE_RGB");
  apolloengine.ShaderEntity.TEXTURE_DIFFUSE_ALPHA =apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_DIFFUSE_ALPHA");
    
  apolloengine.ShaderEntity.TEXTURE_BACKG =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_BACKG");
    
  apolloengine.ShaderEntity.UNIFORM_ALPHACOF =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "UNIFORM_ALPHACOF");
    
  apolloengine.ShaderEntity.UNIFORM_FACETEXPARA =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "UNIFORM_FACETEXPARA");
    
  apolloengine.ShaderEntity.TEXTURE_BACKG_ALPHA =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_BACKG_ALPHA");
  
  apolloengine.ShaderEntity.TEXTURE_BACKG_RGB =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_BACKG_RGB");
    
  apolloengine.ShaderEntity.ATTRIBUTE_FACECOORDNATESTD =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.ATTRIBUTE,
      "ATTRIBUTE_FACECOORDNATESTD");
    
  apolloengine.ShaderEntity.ATTRIBUTE_RADIUS =
        apolloengine.IMaterialSystem:NewParameterSlot(
          apolloengine.ShaderEntity.ATTRIBUTE,
          "ATTRIBUTE_RADIUS");
  
  apolloengine.ShaderEntity.TEXTURE_BEZIER =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_BEZIER");
  apolloengine.ShaderEntity.UNIFORM_CENTERPOS =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "UNIFORM_CENTERPOS");
  apolloengine.ShaderEntity.UNIFORM_NEW_CENTERPOS =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "UNIFORM_NEW_CENTERPOS");

  apolloengine.ShaderEntity.UNIFORM_RATIOASPECT =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
     "UNIFORM_RATIOASPECT");
   
  apolloengine.ShaderEntity.UNIFORM_POSOFFSET =apolloengine.IMaterialSystem:NewParameterSlot(
  apolloengine.ShaderEntity.UNIFORM,
  "UNIFORM_POSOFFSET");
   
  apolloengine.ShaderEntity.ATTRIBUTE_SCREENBGPOS =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.ATTRIBUTE,
      "ATTRIBUTE_SCREENBGPOS");
    
  apolloengine.ShaderEntity.TEXTURE_DIFFUSE_BGALPHA =
    apolloengine.IMaterialSystem:NewParameterSlot(
      apolloengine.ShaderEntity.UNIFORM,
      "TEXTURE_DIFFUSE_BGALPHA");
  
  apolloengine.IMaterialSystem:Preloading(defined.bezier_material_path);
  apolloengine.IMaterialSystem:Preloading(defined.transfer_material_path);
  for _, v in ipairs(sticker2ddefine.materialPath) do
    apolloengine.IMaterialSystem:Preloading(v);
  end
  for _, v in ipairs(facedefinde.materialPath) do
    apolloengine.IMaterialSystem:Preloading(v);
  end
  for _, v in ipairs(sticker2ddefine.materialPathSplit) do
    apolloengine.IMaterialSystem:Preloading(v);
  end
  for _, v in ipairs(facedefinde.materialPathSplit) do
    apolloengine.IMaterialSystem:Preloading(v);
  end
end

return preloading;