local defined
if not _KRATOSEDITOR then
  defined= require "apolloutility.defiend"
end
local venuscore = require "venuscore"


local UsrscriptModule  = venuscore.ActorNode:extend("UsrscriptModule");

UsrscriptModule:MemberRegister("scriptPath");

function UsrscriptModule:new(path)
  self.scriptPath = path;
end

function UsrscriptModule:Initialize(script,node)
  self.componentlist = node.componentList;
  for key,value in pairs(self.componentlist)do
    if string.find(key,'Userscript_') == nil and value:GetTypeName() == "RenderComponent" then
      value:SetSequence(defined.editor_camera_default_sequence);
    elseif string.find(key,'Userscript_') == nil and value:GetTypeName() == "AnimationComponent" then
      local animations = value:GetAnimations();
      for k,v in pairs(animations) do
        value:Play(k); 
        value:Loop(k,true);
      end
    end
  end
end

function UsrscriptModule:Update(def)
end

function UsrscriptModule:ReleaseResource()
  self.componentlist = nil;
end

return UsrscriptModule;
