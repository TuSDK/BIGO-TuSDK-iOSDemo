
--默认配置
local pupildefined = 
{
  pupil_material = "comm:documents/material/pupil.material",
  pupil_max_people = 3,
  pupil_material_begin = [[
                            #include "comm:documents/material/shaders/billboardtransform.shader"
                            #include "comm:documents/material/shaders/transform.shader"
                            #include "comm:documents/material/shaders/sampling.shader"
                            #include "comm:documents/material/shaders/outputs.shader"  
                                                                             
                             #LIGHTING_AMBIENT_FORWARD_SINGLE		ImageBlitTrasnparent 
                             #LIGHTING_DIRECTION_FORWARD_SINGLE			ImageBlitTrasnparent 
                             #LIGHTING_POINT_FORWARD_SINGLE 			ImageBlitTrasnparent 
                             #LIGHTING_SPOT_FORWARD_SINGLE 			ImageBlitTrasnparent 
                                                                                
                             #MATERIAL_DEFINE ImageBlitTrasnparent
                              RENDER_QUEUE = BACKGROUND + 1
                              COLOR_MASK = COLOR_RGBA
	                            ALPAH_MODE = %s
	                            DRAW_MODE = { CULL_FACE_OFF, DEPTH_MASK_OFF, DEPTH_TEST_ON, DEPTH_FUNCTION_LESS } 
	                            STENCIL_MODE = {STENCIL_OFF}]];
  defualt_alpha_mode = "{ ALPAH_BLEND, SRC_ALPHA, ONE_MINUS_SRC_ALPHA , SRC_ALPHA, ONE }";
  pupil_material_end = "#END_DEFINE";
}

return pupildefined;
