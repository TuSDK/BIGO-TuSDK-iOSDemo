
--默认配置
local defined = 
{
    cnnseg_path = "comm:documents/cnnseg/model/",
    singleFrameFloat="model_float",
    cnnseg_modle={ singleFrameFloat="model_float",singleFrameFix="online_seg_model_218MFlops_0.947115916224_lk"
                    ,singleFrameFixCrypt="online_seg_model_218MFlops_0.947115916224_lk_crypt"},

    cnnseg_modle_use="test_lk_crypt",

    bvt_model_path = "comm:documents/bvtmodel/",

    iris_detect_flag = {
      SUCCESS = 0,
      RUNTIME_ERROR = 1,
      PARAMS_ERROR = 2,
      LOAD_MODEL_FAILED = 3,
      INIT_FAILED = 4,
    },

    hand_recongnition_flag = {
      SUCCESS,
      TYPE_ERROR,
      RUNTIME_ERROR,
      PARAMS_ERROR,
      LOAD_MODEL_FAILED,
      INIT_FAILED

    },
    -- 模状态码
    cnnsegFlag= {
        SUCCESS=0,
        FAILED=1 ,
        IDLE =2  ,
        INIT_SETTING_FAILED=3,
        LOAD_MODEL_PARAM_FAILED=4,
        LOAD_MODEL_BIN_FAILED =5 ,
        INPUT_DATA_FAILED =6     ,
        INPUT_MAT_FAILED=7	   ,
        OUTPUT_PROCESS_FAILED=8 ,},
      
    --动作码
    triggerType = {
      NULL          = 0,
      Face          = 1,
      Blink         = 2,
      OpenMouth     = 2^2,
      ShakeHead     = 2^3,
      NodeHead      = 2^4,
      BrowJump      = 2^5,
      OK            = 2^9,
      Scissor       = 2^10,
      ThumbUp       = 2^11,
      Palm          = 2^12,
      Pistol        = 2^13,
      Love          = 2^14,
      Holdup        = 2^15,
      Congratulate  = 2^17,
      FingerHeart   = 2^18,
      IndexFinger   = 2^20
    },
    

    cppTypeOffset = 6,
    faceSegType={CNNSEG_FULL=100,CNNSEG_FULL_HAIR=2},
	
    detectType = {
        DetectTypeBegin = 3,
        Catface = 4,                  
        Face = 5,                     
        PoseEstimation = 6,           
        HandRecognition = 7,          
        ForeheadDetection = 8,        
        IrisDetection = 9,            
        FaceExpression = 10,
        HairSegment = 11,
        HandClassify = 12,
        TongueDetection = 13
    },

    MLDataType = {
        FACE_LANDMARK = 0,
        FACE_ANGULAR = 1 ,
        FACE_ACTION = 2,
        FACE_RECT =3,
        FACE_FOREHEAD =4,
    },

    MLInitStatus = {
        UNINIT = 0 ,
        INITING = 1,
        INITSUCCESS = 2 ,
        INITFAIL = 3,
    },

    MLDetectMode = {
        IMAGE = 0,
        VIDEO = 1,
    },
}

-- 手势动作标记集合
defined.handActionType = defined.triggerType.OK + defined.triggerType.Scissor
        + defined.triggerType.ThumbUp + defined.triggerType.Palm
        + defined.triggerType.Pistol + defined.triggerType.Love
        + defined.triggerType.Holdup + defined.triggerType.Congratulate
        + defined.triggerType.FingerHeart + defined.triggerType.IndexFinger ;

-- 人脸动态表情集合
defined.faceDynamicExpressType = defined.triggerType.Blink
        + defined.triggerType.OpenMouth
        + defined.triggerType.ShakeHead
        + defined.triggerType.NodeHead
        + defined.triggerType.BrowJump ;

-- 人脸检测集合
defined.faceDetectType =  defined.faceDynamicExpressType
        + defined.triggerType.Face ;

return defined;
