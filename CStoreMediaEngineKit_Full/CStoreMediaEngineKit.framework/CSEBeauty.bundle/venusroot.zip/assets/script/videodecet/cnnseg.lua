
if _PLATFORM_WINDOWS then
  return require"videodecet.cnnsegg" 
elseif _PLATFORM_ANDROID then
  return require"videodecet.cnnsegg"
elseif _PLATFORM_IOS then
  return require"videodecet.cnnsegg"
end
