local ActionInfo = require "videodecet.actioninfo";
local Faceinfo = require "videodecet.faceinfo";
local stringsplit = require "stringsplit"

local paserservice = {}

function paserservice:GetKeyPointCount()
  return 14;
end

function paserservice:PaserFile(agent, index, videosize, fullpath)
  for line in io.lines(fullpath) do
    local data = stringsplit(line, "%s", tonumber);
    table.remove(data, #data);
    agent:CallbackFunction(index, data);
  end
end

return paserservice;