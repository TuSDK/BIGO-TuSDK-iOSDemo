if _PLATFORM_WINDOWS then
  --local vd = require"videodecet.windowsvideodetect_camera" 
  --if vd:TryOpenCamera() then
  --  return vd;
  --end  
  return require"videodecet.windowsvideodetect_file"
  --return require"videodecet.windowsvideodetect_body"
elseif _PLATFORM_ANDROID then
  return require"videodecet.androidvideodetect"
elseif _PLATFORM_IOS then
  return require"videodecet.androidvideodetect"
end
  