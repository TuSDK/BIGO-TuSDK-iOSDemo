
local basedetect = {}
local mt = {__index = basedetect}

function basedetect:isAction(id)
  local actions = self:GetActions();--返回当前识别出来的动作
  if actions then
    for _, pepole in ipairs(actions) do
      for _, act in ipairs(pepole) do
        if act:GetActionID() == id then
          return true, act;
        end      
      end
    end
  end
  return false, nil;
end

return mt;