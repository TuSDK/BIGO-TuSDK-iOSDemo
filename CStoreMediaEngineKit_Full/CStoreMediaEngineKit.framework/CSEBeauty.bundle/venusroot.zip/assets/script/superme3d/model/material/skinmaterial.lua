
local apollonode = require "apolloutility.apollonode"
local mathfunction = require "mathfunction"
local apolloengine = require "apolloengine"

--默认简单材质
local DefaultMaterial = {};

--外部会调用此接口创建材质
function DefaultMaterial:SetupMaterial(meshNode)
  apolloengine.ShaderEntity.VIEW_POSITION = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.INTERNAL,"VIEW_POSITION");

  apolloengine.ShaderEntity.WORLDSPACE_POSITION = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.INTERNAL,"WORLDSPACE_POSITION");


  apolloengine.ShaderEntity.VIEW_DIRECTION = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.INTERNAL,"VIEW_DIRECTION");

  apolloengine.ShaderEntity.WORLDSPACE_NORMAL = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.INTERNAL,"WORLDSPACE_NORMAL");
  --基础反射色
  apolloengine.ShaderEntity.WORLDSPACE_TANGENT = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.INTERNAL,"WORLDSPACE_TANGENT");

  apolloengine.ShaderEntity.LIGHTING_DIFFUSE = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.INTERNAL,"LIGHTING_DIFFUSE");

  --世界空间转到切线空间的矩阵
  apolloengine.ShaderEntity.W2T_TBN_MAT = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.INTERNAL,"W2T_TBN_MAT");

  --切线空间转到世界空间的矩阵
  apolloengine.ShaderEntity.T2W_TBN_MAT = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.INTERNAL,"T2W_TBN_MAT");

  apolloengine.ShaderEntity.SKY_BOX = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"SKY_BOX");
  
  apolloengine.ShaderEntity.BECKMANN_TEX = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TEXTURE_BECKMANN");
  
  apolloengine.ShaderEntity.TEXTURE_NORMAL = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.UNIFORM,"TEXTURE_NORMAL");
  

  apolloengine.ShaderEntity.REAL_WORLDSPACE_DEPTH = apolloengine.IMaterialSystem:NewParameterSlot(apolloengine.ShaderEntity.INTERNAL,"REAL_WORLDSPACE_DEPTH");
--[[
  local skybox = apolloengine.TextureEntity();
  skybox:PushMetadata(apolloengine.TextureFileMetadata("docs:skybox/front.jpg"));
  skybox:PushMetadata(apolloengine.TextureFileMetadata("docs:skybox/back.jpg"));
  skybox:PushMetadata(apolloengine.TextureFileMetadata("docs:skybox/top.jpg"));
  skybox:PushMetadata(apolloengine.TextureFileMetadata("docs:skybox/bottom.jpg"));
  skybox:PushMetadata(apolloengine.TextureFileMetadata("docs:skybox/left.jpg"));
  skybox:PushMetadata(apolloengine.TextureFileMetadata("docs:skybox/right.jpg"));
  skybox:CreateResource();
  apolloengine.IMaterialSystem:SetGlobalParameter(apolloengine.ShaderEntity.SKY_BOX,skybox);
]]--
 -- meshNode:SetMaterialPath("comm:documents/material/nl_simple.material");
  meshNode:SetMaterialPath("comm:documents/material/skin_normal.material");
  --meshNode:SetMaterialPath("docs:superme3d/material/skin.material");
end
return DefaultMaterial;