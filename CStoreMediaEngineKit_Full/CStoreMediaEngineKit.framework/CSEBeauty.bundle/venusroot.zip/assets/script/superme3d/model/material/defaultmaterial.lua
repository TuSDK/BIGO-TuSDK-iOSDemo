
local apollonode = require "apolloutility.apollonode"
local mathfunction = require "mathfunction"
local apolloengine = require "apolloengine"

--默认简单材质
local DefaultMaterial = {};

--外部会调用此接口创建材质
function DefaultMaterial:SetupMaterial(meshNode)
  meshNode:SetMaterialPath("comm:documents/material/skeleton4bmatrix.material");
end
return DefaultMaterial;