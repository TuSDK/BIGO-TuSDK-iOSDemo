
--默认配置
local superme3d_defined = 
{
  
  --各个部件的配置要下放到素材中
  Event = 
  {
    ON_INITIALIZE = "OnInitialize",
    ON_RESOURCE_ROOTPATH = "OnResourceRootPath",
    ON_RESOURCE_VERSION = "OnResourceVersion",
    ON_RESOURCE_MODEL_LIST = "OnResourceModelList",   --传递模型列表
    ON_RESOURCE_MODEL_ITEM = "OnResourceModelItem",
    ON_RESOURCE_BACKGROUND = "OnResourceBackground",
    ON_RESOURCE_SKELETON = "OnResourceSkeleton",
    ON_RESOURCE_MODEL_ITEM_PATH = "OnResourceModelItemPath",
    ON_RELEASE_RESOURCE = "OnReleaseResource",
    ON_CREATE_MESH_NODE = "OnCreateMeshNode",
    ON_CREATE_MESH_NODE_FINISHED = "OnCreateMeshNodeFinished",
    ON_CREATE_SKELETON_FINISHED = "OnCreateSkeletonFinished",
    ON_CREATE_MATERIAL = "OnCreateMaterial",
    ON_UPDATE = "OnUpdate"
  },
  
  --各个部件材质配置
  Materials = 
  {
    Skin = "scrs:superme3d/model/material/skinmaterial.lua",    --真实感皮肤材质
    --Skin = "scrs:superme3d/model/material/defaultmaterial.lua",    --真实感皮肤材质
    Farbric = "scrs:superme3d/model/material/farbricmaterial.lua",  --真实感布料材质
    Hair = "scrs:superme3d/model/material/hairmaterial.lua",  --真实感头发材质
    Simple = "scrs:superme3d/model/material/defaultmaterial.lua",    --普通材质,
    Default = "scrs:superme3d/model/material/defaultmaterial.lua"
  },
  
  
  --DefaultMesh = "docs:superme3d/mesh/Legs",
  DefaultSkeleton = "docs:../../testcase/documents/3dsuperme2/skeleton",
  
  --[[
  DefaultMesh = 
  { 
    {
      Path = "docs:superme3d/mesh/DownSkin",
    }
  },
  
  --默认人体骨骼，身体部分公用同一套骨骼
  DefaultSkeleton = 
  {
    Name = "docs:superme3d/skeleton/skel.ske",
    HasScale = true  --骨骼是否有缩放
  }
  --]]
}



return superme3d_defined;