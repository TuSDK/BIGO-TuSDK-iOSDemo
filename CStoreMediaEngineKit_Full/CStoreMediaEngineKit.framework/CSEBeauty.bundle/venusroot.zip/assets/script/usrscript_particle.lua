local venuscore = require "venuscore"
local apolloengine = require "apollocore"
local mathfunction = require "mathfunction"
local defined
if not _KRATOSEDITOR then
  defined= require "apolloutility.defiend"
end

local UsrscriptParticle  = venuscore.ActorNode:extend("UsrscriptParticle");

UsrscriptParticle:MemberRegister("scriptPath");

function UsrscriptParticle:new(path)
  self.scriptPath = path;
end

function UsrscriptParticle:Initialize(script,node)
  self.particleRender = node.RenerComponent;
  self.particleRender:SetSequence(defined.editor_camera_default_sequence);
  self.cpuEmitter = node:GetNativeNode();
  self.cpuEmitter:Start();
end

function UsrscriptParticle:Update(def)  
end

function UsrscriptParticle:ReleaseResource()
  self.particleRender = nil;
  self.cpuEmitter = nil
end

return UsrscriptParticle;
