





local MaskSequence = require "biugo.mask_sequence_mobile"
local biugodefined = require "biugo.defined"
local FMorph = require "biugo.morph"

local Object = require "classic"



local MorphSequence = MaskSequence:extend();

function MorphSequence:new(customID,channel, isText, materialName, alphaMode, splitInfo,morphInfo,fboSize)
  MorphSequence.super.new(self,customID,channel, isText, materialName, alphaMode, splitInfo);
  self.faceMorph = FMorph(morphInfo,fboSize);
  self.custom_texture = nil;
end

--重载取图片的函数
function MorphSequence:GetCustomTexture()
  
  --变脸只需要取一次图
  if self.custom_texture == nil then
    local custom_texture = self.faceMorph:GetMorphResult();
    self.custom_texture = custom_texture;
    self.custom_texture_size = custom_texture:GetSize();
    self:SetShow(true);
  end
  

end

function MorphSequence:Update(timespan)
  
  self.faceMorph:Update(timespan);

  MorphSequence.super.Update(self,timespan);
end

function MorphSequence:DoMorph(indiceslist, showtimelist, transtimelist)
  return self.faceMorph:DoMorph(indiceslist, showtimelist, transtimelist);
end

function MorphSequence:Clear()
  if self.faceMorph then
    self.faceMorph:Clear();
  end
end




return MorphSequence;


