

local SequenceAnimation = require "apolloutility.sequenceanimation"
local basedetect = require "videodecet.basevideodetect";
local apollonode = require "apolloutility.apollonode"
local renderqueue = require "apolloutility.renderqueue"
local defiend = require "apolloutility.defiend"
local apolloengine = require "apolloengine"
local mathfunction = require "mathfunction"
local venuscore = require "venuscore"
local videodecet = require "videodecet"
local biugodefined = require "biugo.defined"
local asynctexture = require "apolloutility.asynctexture.asynctexture"




local MaskSequence = require "biugo.mask_sequence_windows"

local FMorph = require "biugo.morph"

local Object = require "classic"



local MorphSequence = MaskSequence:extend();

function MorphSequence:new(customID,channel, isText, materialName, alphaMode, splitInfo,morphInfo,fboSize)
  MorphSequence.super.new(self,customID,channel, isText, materialName, alphaMode, splitInfo);
  self.faceMorph = FMorph(morphInfo,fboSize);
end

--重写Update
function MorphSequence:Update(timespan)
  
  self.faceMorph:Update(timespan);
  local custom_texture = self.faceMorph:GetMorphResult();
  self.custom_texture = custom_texture;
  
  local rgb, alpha, frame, isplaying = 0;
  rgb, frame, alpha, isplaying = self.mask_imagereader:Update(timespan);
  --LOG("FrameIndex is: " .. tostring(frame));
  if rgb and isplaying then
    self.mask_texture = rgb;
  else
    self.mask_textrue = self.empty_mask_texture;
  end
  MaskSequence.super.Update(self,frame);
end

function MorphSequence:DoMorph(indiceslist, showtimelist, transtimelist)
  return self.faceMorph:DoMorph(indiceslist, showtimelist, transtimelist);
end



return MorphSequence;


