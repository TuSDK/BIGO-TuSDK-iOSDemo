if _PLATFORM_WINDOWS then
  return require "biugo.morph_sequence_window"
elseif _PLATFORM_ANDROID then
  return require "biugo.morph_sequence_mobile"
elseif _PLATFORM_IOS then
  return require "biugo.morph_sequence_mobile"
end