

local FaceMophBase = require "biugo.morph_base"
local biugodefined = require "biugo.defined"
local Object = require "classic"



local FaceMorph = FaceMophBase:extend();


function FaceMorph:new(morphInfo,fboSize)
  FaceMorph.super.new(self,morphInfo,fboSize);
end


return FaceMorph;


