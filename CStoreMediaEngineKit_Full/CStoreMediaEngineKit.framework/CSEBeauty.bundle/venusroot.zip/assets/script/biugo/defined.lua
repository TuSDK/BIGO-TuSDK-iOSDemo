
--默认配置
local biugodefined = 
{
  photomood_base_blend_camera_sequence = -2900,
  mask_video_material_path = "docs:biugo/material/mask_video.material",
  --下面的为windows测试
  windows_mask_sequence_path = "comm:documents/mask/",

  windows_mask_sequence_name = "%04d.jpg",
  windows_custom_texture_path = "comm:documents/customtexture/",
  windows_custom_texture_name = "output3.png",
  
  FaceMorphTemplate = 
  {
    {
        image = "docs:facemorph/resource/man.png",
        landmark = "docs:facemorph/resource/man.txt"
    },
    {
        image = "docs:facemorph/resource/women.png",
        landmark = "docs:facemorph/resource/women.txt"
    }
  },
      
  
  base_material_begin = [[
    #include "docs:biugo/material/shaders/base_video.shader"

    #LIGHTING_AMBIENT_FORWARD_SINGLE    BaseVideoMaterial 
    #LIGHTING_DIRECTION_FORWARD_SINGLE  BaseVideoMaterial 
    #LIGHTING_POINT_FORWARD_SINGLE      BaseVideoMaterial 
    #LIGHTING_SPOT_FORWARD_SINGLE       BaseVideoMaterial 
                                                              
    #MATERIAL_DEFINE BaseVideoMaterial 
      RENDER_QUEUE = %s
      COLOR_MASK = COLOR_RGBA 
      ALPAH_MODE = %s
      DRAW_MODE = { CULL_FACE_OFF, DEPTH_MASK_OFF, DEPTH_TEST_ON, DEPTH_FUNCTION_LESS } 
      STENCIL_MODE = {STENCIL_OFF}]];
  
  material_begin = [[
                      #include "docs:biugo/material/shaders/mask_video.shader"
                                                                             
                      #LIGHTING_AMBIENT_FORWARD_SINGLE		CutmeMaterial 
                      #LIGHTING_DIRECTION_FORWARD_SINGLE	CutmeMaterial 
                      #LIGHTING_POINT_FORWARD_SINGLE 			CutmeMaterial 
                      #LIGHTING_SPOT_FORWARD_SINGLE 			CutmeMaterial 
                                                                                
                      #MATERIAL_DEFINE CutmeMaterial 
                        RENDER_QUEUE = OPAQUE 
                        COLOR_MASK = COLOR_RGBA 
                        ALPAH_MODE = %s
                        DRAW_MODE = { CULL_FACE_OFF, DEPTH_MASK_OFF, DEPTH_TEST_ON, DEPTH_FUNCTION_LESS } 
                        STENCIL_MODE = {STENCIL_OFF}]],
  material_end = "#END_DEFINE";
  
  AlphaMode = 
  {
      Blend = "{ ALPAH_BLEND, SRC_ALPHA, ONE_MINUS_SRC_ALPHA , ONE, ONE }",
      Add = "{ ALPAH_BLEND, SRC_ALPHA, ONE , SRC_ALPHA, ONE }"
  },

  BlendMode = 
  {
      Overlay = "comm:script/apolloengine/posteffect/blend_overlay.lua",
      Screen = "comm:script/apolloengine/posteffect/blend_screen.lua",
      SoftLight = "comm:script/apolloengine/posteffect/blend_softlight.lua",
      Normal = "comm:script/apolloengine/posteffect/blend_normal.lua",
      Add = "comm:script/apolloengine/posteffect/blend_add.lua"
     
  },

  Shaders = 
  {
      Simple = [[
       	VERTEX_SHADER = 
        {
          "MaskVideoVertex_Cutme"
        }
        FRAGMENT_SHADER = 
        {
          "MaskVideoFragment_Cutme"
        }
      ]],
      SimpleV2 = [[
       	VERTEX_SHADER = 
        {
          "MaskVideoVertex_Cutme"
        }
        FRAGMENT_SHADER = 
        {
          "MaskVideoFragment_Version2_Cutme"
        }
      ]],
      GaussBlur = [[
      ]],
      BaseVideo = [[
        VERTEX_SHADER = 
        {
          "BaseVideoVertex"
        }
        FRAGMENT_SHADER = 
        {
          "BaseVideoFragment"
        }
      ]]
      
  }
}



return biugodefined;